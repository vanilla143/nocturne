// User Types
export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  createdAt: string;
  updatedAt: string;
  isPro: boolean;
  xp: number;
  level: number;
  dailyStreak: number;
  lastReflectionDate?: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  token: string | null;
}

// Personality Scan Types
export interface Question {
  id: string;
  text: string;
  category: 'values' | 'fears' | 'ambitions' | 'conflict' | 'decision' | 'trauma' | 'communication' | 'emotional';
  options: QuestionOption[];
}

export interface QuestionOption {
  id: string;
  text: string;
  score: Record<string, number>;
}

export interface PersonalityScore {
  coreValue: number;
  emotionalPattern: number;
  ambitionLevel: number;
  riskTendency: number;
  attachmentStyle: number;
  existentialDepth: number;
}

export interface PersonalityProfile {
  id: string;
  userId: string;
  scores: PersonalityScore;
  dominantTraits: string[];
  analysis: string;
  createdAt: string;
}

// Alter Ego Types
export interface AlterEgo {
  id: string;
  userId: string;
  name: string;
  title: string;
  description: string;
  speakingStyle: string;
  tone: 'wise' | 'brutal' | 'philosophical' | 'motivator';
  personality: string;
  avatar?: string;
  energy: number;
  maxEnergy: number;
  unlockedTones: string[];
  createdAt: string;
  updatedAt: string;
}

// Chat Types
export interface ChatMessage {
  id: string;
  userId: string;
  alterEgoId: string;
  role: 'user' | 'assistant';
  content: string;
  mode: 'wise' | 'brutal' | 'philosophical' | 'motivator';
  timestamp: string;
  emotion?: string;
}

export interface ChatSession {
  id: string;
  userId: string;
  alterEgoId: string;
  messages: ChatMessage[];
  startedAt: string;
  lastMessageAt: string;
}

// Simulation Types
export interface SimulationScenario {
  id: string;
  userId: string;
  input: string;
  scenarios: FutureScenario[];
  createdAt: string;
}

export interface FutureScenario {
  id: string;
  title: string;
  probability: number;
  narrative: string;
  risks: string[];
  emotionalConsequences: string[];
  growthPotential: string[];
  timeline: string;
}

// Writing Types
export interface WritingPiece {
  id: string;
  userId: string;
  input: string;
  type: 'poem' | 'reflection' | 'letter' | 'monologue';
  style: 'poetic' | 'minimalist' | 'dark' | 'realistic' | 'existential';
  content: string;
  title: string;
  createdAt: string;
}

// Level System Types
export interface LevelSystem {
  currentLevel: number;
  currentXP: number;
  xpToNextLevel: number;
  totalXP: number;
  achievements: Achievement[];
  unlockedFeatures: string[];
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlockedAt?: string;
  xpReward: number;
}

export interface LevelReward {
  level: number;
  reward: string;
  type: 'tone' | 'feature' | 'title';
}

// UI Types
export interface Toast {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  message: string;
  duration?: number;
}

export interface ModalState {
  isOpen: boolean;
  type: string | null;
  data?: any;
}

// API Types
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  hasMore: boolean;
}
