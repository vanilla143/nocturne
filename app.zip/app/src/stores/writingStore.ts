import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { WritingPiece } from '@/types';

type WritingType = 'poem' | 'reflection' | 'letter' | 'monologue';
type WritingStyle = 'poetic' | 'minimalist' | 'dark' | 'realistic' | 'existential';

interface WritingState {
  currentPiece: WritingPiece | null;
  isGenerating: boolean;
  history: WritingPiece[];
  generateWriting: (input: string, type: WritingType, style: WritingStyle) => Promise<void>;
  clearCurrent: () => void;
  exportToPDF: (piece: WritingPiece) => void;
}

const generateContent = (input: string, type: WritingType, style: WritingStyle): { title: string; content: string } => {
  // Poem templates with different styles
  const poemTemplates: Record<WritingStyle, () => { title: string; content: string }> = {
    poetic: () => ({
      title: 'Larung',
      content: `Di dalam sunyi yang kau rasakan,
Ada getaran yang tak pernah padam.
${input}—bukan kekosongan,
Tapi ruang untuk sesuatu yang baru lahir.

Seperti sungai yang mencari laut,
Seperti bintang yang menemui fajar,
Kamu adalah perjalanan yang belum selesai ditulis.

Biarkan malam mengajarmu
Bahwa gelap bukanlah musuh,
Tapi kanvas untuk cahaya
Yang akan datang pada waktanya.`,
    }),
    minimalist: () => ({
      title: 'Kosong',
      content: `${input}

Bukan akhir.
Bukan awal.

Hanya
ada.

Dan itu
cukup.`,
    }),
    dark: () => ({
      title: 'Cermin Gelap',
      content: `${input}

Kata-kata yang tak terucap
Menggantung di udara
Seperti mayat yang tak dikehendaki.

Di dalam lubuk yang paling gelap,
Kau menemukan:
Bukan monster,
Tapi bayangan dari dirimu
Yang tak pernah diterima.

Biarkan ia tinggal.
Biarkan ia mengajarimu
Bahwa terkadang,
Yang paling menakutkan
Adalah yang paling jujur.`,
    }),
    realistic: () => ({
      title: 'Catatan',
      content: `${input}

Hari ini rasanya berat.
Bukan karena ada sesuatu yang salah,
Tapi karena segalanya terasa... kosong.

Dan itu normal.

Tidak setiap hari harus penuh makna.
Tidak setiap momen harus diingat.

Kadang, hidup hanya tentang
melewati.

Dan itu juga cukup.`,
    }),
    existential: () => ({
      title: 'Pertanyaan untuk Keheningan',
      content: `${input}

Di antara detak-detak jam yang tak pernah berhenti,
Kamu bertanya: untuk apa?

Jawabannya bukan di luar sana.
Bukan dalam buku, atau kata-kata bijak,
Atau pengakuan dari orang lain.

Jawabannya—jika memang ada—
Adalah dalam keberanianmu
Untuk terus bertanya.

Karena mungkin,
Hidup bukan tentang menemukan jawaban,
Tapi tentang belajar hidup
Dengan pertanyaan-pertanyaan itu.`,
    }),
  };

  // Reflection templates with different styles
  const reflectionTemplates: Record<WritingStyle, () => { title: string; content: string }> = {
    poetic: () => ({
      title: 'Jejak',
      content: `Hari ini aku merasa: ${input}

Seperti jejak kaki di pasir yang akan segera terhapus ombak,
perasaan ini datang—tidak diundang, tidak dipinta.

Aku mencoba menangkapnya, memahaminya,
tapi ia licin seperti air di antara jari-jariku.

Mungkin tidak semua perlu dipahami.
Mungkin beberapa hal cukup dirasakan,
lalu dilepaskan,
seperti daun yang gugur di musim gugur.

${input}.

Aku mencatatmu di sini,
bukan untuk mengungkapkan,
tapi untuk mengakui
bahwa kamu pernah ada.`,
    }),
    minimalist: () => ({
      title: 'Refleksi',
      content: `${input}

Ini yang kurasakan hari ini.
Tidak perlu diperbaiki.
Tidak perlu diubah.

Hanya perlu dilihat.
Dicatat.
Diterima.

Besok mungkin berbeda.
Atau mungkin sama.

Tidak apa-apa.`,
    }),
    dark: () => ({
      title: 'Luka yang Bicara',
      content: `${input}

Ada sesuatu yang meronta di dalam.
Sesuatu yang tidak mau diam.
Sesuatu yang menuntut untuk didengar.

Aku biasanya menenggelamkannya.
Dengan distraksi. Dengan kebisingan.
Dengan segala cara agar tidak merasakannya.

Tapi malam ini, aku biarkan ia bicara.
${input}

Dan yang kudengar bukan kelemahan.
Yang kudengar adalah kebenaran
yang telah lama kupendam.

Berbahayakah kebenaran?
Mungkin.
Tapi berbahayakah juga kebohongan
yang kupakai untuk menutupinya?`,
    }),
    realistic: () => ({
      title: 'Evaluasi',
      content: `Situasi: ${input}

Analisis:
Perasaan ini valid. Ia punya alasan untuk ada.
Mungkin dipicu oleh sesuatu.
Mungkin hanya akumulasi dari banyak hal kecil.

Tindakan:
Tidak perlu tindakan segera.
Cukup diamati. Dicatat. Dipantau.

Ekspektasi:
Perasaan ini akan berlalu.
Mungkin dalam beberapa jam.
Mungkin dalam beberapa hari.

Catatan:
Hidup terus berjalan.`,
    }),
    existential: () => ({
      title: 'Mediasi',
      content: `${input}

Di tengah hiruk-pikuk eksistensi,
ada momen diam seperti ini.
Momen ketika semua topeng terlepas.
Ketika semua peran terhenti.
Ketika yang tersisa hanyalah
aku
yang bertanya:

Siapa yang merasa ini?
Apakah aku hanyalah kumpulan perasaan
yang berganti-ganti?
Atau ada sesuatu yang lebih dalam,
sebuah pengamat yang tetap,
di tengah badai emosi?

${input}.

Aku tidak mencari jawaban.
Aku hanya hadir
bersama pertanyaan.`,
    }),
  };

  // Letter templates with different styles
  const letterTemplates: Record<WritingStyle, () => { title: string; content: string }> = {
    poetic: () => ({
      title: 'Surat dari Masa Depan',
      content: `Sayangku,

Aku menulis dari tempat di mana ${input}
sudah menjadi kenangan yang samar.

Dari sini, aku bisa melihat
bagaimana semuanya terhubung—
setiap air mata, setiap keraguan,
setiap malam yang panjang.

Mereka bukan penghalang.
Mereka adalah tangga
yang kautapaki
untuk sampai di sini.

Jadi teruslah.
Satu langkah demi satu langkah.
Percayalah bahwa setiap langkah,
meski terasa sia-sia,
membawamu lebih dekat
kepada siapa kamu sebenarnya.

Dengan cinta yang melintasi waktu,
Aku yang akan menjadi`,
    }),
    minimalist: () => ({
      title: 'Surat',
      content: `Kepada diriku,

${input}

Ini akan berlalu.
Kamu akan baik-baik saja.

Percaya.

Aku.`,
    }),
    dark: () => ({
      title: 'Surat dari Bayangan',
      content: `Kamu yang tersembunyi,

Aku tahu kamu ada di sana.
Di balik senyum, di balik "aku baik-baik saja."
Aku tahu karena aku adalah kamu.

${input}

Ini bukan kelemahan.
Ini bukan sesuatu yang harus diperbaiki.
Ini adalah bagian dari kita
yang telah lama diabaikan.

Mari berhenti berlari.
Mari hadapi ini bersama.
Bukan untuk menyembuhkan—
tapi untuk mengintegrasikan.

Karena kita tidak utuh
tanpa bagian ini.

Dari kegelapan yang mencintaimu,
Bayanganmu.`,
    }),
    realistic: () => ({
      title: 'Catatan untuk Diri Sendiri',
      content: `Halo,

Situasi saat ini: ${input}

Fakta:
- Ini tidak nyaman
- Ini tidak permanen
- Kamu pernah melewati yang lebih buruk

Tindakan yang bisa dilakukan:
1. Bernapas
2. Istirahat jika perlu
3. Cari bantuan jika terlalu berat

Ingat:
Perasaan bukan fakta.
Mereka hanya informasi.
Gunakan mereka dengan bijak.

Sampai jumpa di lain waktu,
Dirimu yang lebih tenang`,
    }),
    existential: () => ({
      title: 'Surat dari Keberadaan',
      content: `Yang ada,

${input}

Pernahkah kamu bertanya:
Siapa yang merasa ini?
Bukan pikiranmu—pikiran hanya menginterpretasi.
Bukan tubuhmu—tubuh hanya merespons.

Ada sesuatu yang lebih dalam.
Sesuatu yang menyaksikan.
Sesuatu yang tetap
ketika segalanya berubah.

Temui aku di sana.
Di tempat di mana tidak ada nama,
di mana tidak ada cerita,
di mana hanya ada
kehadiran murni.

Di situlah kita akan menemukan
bahwa ${input}
adalah hanya gelombang di permukaan,
dan di bawahnya,
lautan ketenangan menunggu.

Dalam keheningan,
Keberadaan.`,
    }),
  };

  // Monologue templates with different styles
  const monologueTemplates: Record<WritingStyle, () => { title: string; content: string }> = {
    poetic: () => ({
      title: 'Arietta',
      content: `*suara lembut, hampir seperti bernyanyi*

${input}...

*ia mengulang kata-kata itu, membiarkannya menggema*

Ada musik di dalamnya, tahukah kamu?
Bukan musik yang ceria.
Musik yang dalam. Yang tua. Yang bijaksana.

*bergerak perlahan, seolah-olah menari dengan bayangannya*

Kita pikir kita tahu artinya.
Tapi makna itu seperti air—
berubah bentuk sesuai wadahnya.

*berhenti, menatap ke kejauhan*

Hari ini, wadahnya adalah hatimu.
Dan hatimu... hatimu adalah tempat yang dalam.

*senyum tipis*

Teruslah tenggelam.
Yang terdalam seringkali
menyimpan permata.

*lampu meredup, tapi matanya tetap bersinar*`,
    }),
    minimalist: () => ({
      title: 'Suara',
      content: `*hening*

${input}

*jeda panjang*

Itu saja.

Tidak perlu lebih.

*lampu padam*`,
    }),
    dark: () => ({
      title: 'Seruan',
      content: `*suara dari kegelapan*

Kamu bilang ${input}

Tapi apa yang sebenarnya kamu maksud?
Apakah kamu berani mengatakannya?
Atau hanya bersembunyi di balik kata-kata yang aman?

*langkah kaki yang mendekat*

Aku tahu kebenarannya.
Aku selalu tahu.
Karena aku adalah bagian dari dirimu
yang kamu takuti.
Bagian yang kamu kunci.
Bagian yang kamu hiraukan.

*tawa yang tidak berbahagia*

Tapi aku masih di sini.
Menunggu.
Menyaksikan.
Mengingatkan.

${input}

Ini bukan keluhan.
Ini adalah seruan dari dalam kubur
yang kamu gali untukku.

*keheningan yang menekan*

Bangunkan aku.
Atau biarkan aku bangkit sendiri.

*suara pintu yang berderit*`,
    }),
    realistic: () => ({
      title: 'Catatan Suara',
      content: `*suara datar, hampir monoton*

Jadi, ${input}

*bergerak sedikit, menyesuaikan posisi*

Ini bukan pertama kalinya.
Kamu tahu itu.
Aku tahu itu.
Jadi mari kita lewati bagian di mana kita berpura-pura terkejut.

*menghela napas*

Yang perlu ditanyakan:
Apa yang berbeda kali ini?
Apa yang bisa dilakukan?
Apa yang perlu diterima?

*jeda*

Tidak perlu jawaban sekarang.
Tapi perlu dipikirkan.

*suara kertas yang bergerak*

Aku akan menunggu.
Kamu tahu di mana menemukanku.

*klik—rekaman berakhir*`,
    }),
    existential: () => ({
      title: 'Monolog Absurd',
      content: `*suara yang datang dari segala arah dan tidak ada arah*

${input}

*tertawa, tapi tidak ada humor di dalamnya*

Kamu pikir ini penting?
Kamu pikir ini berarti sesuatu?

*bergerak, tapi bayangannya tidak mengikuti*

Di dalam skema kosmik yang luas,
di tengah alam semesta yang tidak peduli,
apakah ${input}
memiliki makna?

*berhenti, menatap ke kekosongan*

Tapi inilah keindahannya, bukan?
Kita yang memberi makna.
Kita yang menciptakan signifikansi
dari ketiadaan.

*senyum yang anehnya menenangkan*

Jadi ${input}
bukan masalah.
Bukan solusi.
Bukan apa-apa.

Dan dalam kenyataan itu,
ada kebebasan.

*redup perlahan, seperti bintang yang padam*`,
    }),
  };

  // Select the appropriate template based on type
  switch (type) {
    case 'poem':
      return poemTemplates[style]();
    case 'reflection':
      return reflectionTemplates[style]();
    case 'letter':
      return letterTemplates[style]();
    case 'monologue':
      return monologueTemplates[style]();
    default:
      return poemTemplates[style]();
  }
};

export const useWritingStore = create<WritingState>()(
  persist(
    (set, get) => ({
      currentPiece: null,
      isGenerating: false,
      history: [],

      generateWriting: async (input: string, type: WritingType, style: WritingStyle) => {
        set({ isGenerating: true });
        
        // Simulate generation delay
        await new Promise(resolve => setTimeout(resolve, 2000));

        const { title, content } = generateContent(input, type, style);
        
        const piece: WritingPiece = {
          id: `writing-${Date.now()}`,
          userId: 'current-user',
          input,
          type,
          style,
          content,
          title,
          createdAt: new Date().toISOString(),
        };

        set({
          currentPiece: piece,
          history: [piece, ...get().history],
          isGenerating: false,
        });
      },

      clearCurrent: () => {
        set({ currentPiece: null });
      },

      exportToPDF: (piece: WritingPiece) => {
        // This will be implemented with jsPDF
        console.log('Exporting to PDF:', piece);
      },
    }),
    {
      name: 'noctura-writing',
    }
  )
);
