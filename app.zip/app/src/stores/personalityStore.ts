import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Question, PersonalityScore, PersonalityProfile } from '@/types';

interface PersonalityState {
  currentQuestionIndex: number;
  answers: Record<string, string>;
  scores: PersonalityScore;
  profile: PersonalityProfile | null;
  isCompleted: boolean;
  questions: Question[];
  setAnswer: (questionId: string, optionId: string, scores: Record<string, number>) => void;
  nextQuestion: () => void;
  previousQuestion: () => void;
  calculateScores: () => void;
  resetScan: () => void;
  getCurrentQuestion: () => Question | null;
  getProgress: () => number;
}

const questions: Question[] = [
  {
    id: 'q1',
    text: 'Ketika menghadapi keputusan besar, apa yang paling kamu prioritaskan?',
    category: 'decision',
    options: [
      { id: 'q1-a', text: 'Logika dan analisis mendalam', score: { coreValue: 3, riskTendency: 2 } },
      { id: 'q1-b', text: 'Perasaan dan intuisi', score: { emotionalPattern: 3, attachmentStyle: 2 } },
      { id: 'q1-c', text: 'Dampak jangka panjang pada masa depan', score: { ambitionLevel: 3, existentialDepth: 2 } },
      { id: 'q1-d', text: 'Pendapat orang-orang terdekat', score: { attachmentStyle: 3, emotionalPattern: 1 } },
    ],
  },
  {
    id: 'q2',
    text: 'Apa ketakutan terbesar yang menghantui pikiranmu di malam hari?',
    category: 'fears',
    options: [
      { id: 'q2-a', text: 'Gagal mencapai potensi penuhku', score: { ambitionLevel: 3, existentialDepth: 2 } },
      { id: 'q2-b', text: 'Kehilangan orang-orang yang kucintai', score: { attachmentStyle: 3, emotionalPattern: 2 } },
      { id: 'q2-c', text: 'Hidup tanpa makna dan tujuan', score: { existentialDepth: 3, coreValue: 2 } },
      { id: 'q2-d', text: 'Tidak cukup baik atau layak', score: { emotionalPattern: 3, coreValue: 1 } },
    ],
  },
  {
    id: 'q3',
    text: 'Bagaimana kamu biasanya menangani konflik?',
    category: 'conflict',
    options: [
      { id: 'q3-a', text: 'Hadapi langsung dengan diplomatis', score: { coreValue: 3, riskTendency: 2 } },
      { id: 'q3-b', text: 'Mundur dan renungkan dulu', score: { emotionalPattern: 3, existentialDepth: 2 } },
      { id: 'q3-c', text: 'Cari solusi yang menguntungkan semua pihak', score: { attachmentStyle: 3, ambitionLevel: 1 } },
      { id: 'q3-d', text: 'Ekspresikan emosi dengan jujur', score: { riskTendency: 3, emotionalPattern: 2 } },
    ],
  },
  {
    id: 'q4',
    text: 'Apa yang paling kamu cari dalam hidup?',
    category: 'values',
    options: [
      { id: 'q4-a', text: 'Kebebasan dan eksplorasi', score: { riskTendency: 3, existentialDepth: 2 } },
      { id: 'q4-b', text: 'Kedalaman dan makna', score: { existentialDepth: 3, coreValue: 2 } },
      { id: 'q4-c', text: 'Prestasi dan pengakuan', score: { ambitionLevel: 3, coreValue: 1 } },
      { id: 'q4-d', text: 'Hubungan yang bermakna', score: { attachmentStyle: 3, emotionalPattern: 2 } },
    ],
  },
  {
    id: 'q5',
    text: 'Ketika kamu merasa terluka, apa reaksi pertamamu?',
    category: 'trauma',
    options: [
      { id: 'q5-a', text: 'Menganalisis mengapa ini terjadi', score: { coreValue: 3, existentialDepth: 2 } },
      { id: 'q5-b', text: 'Menarik diri dan memproses sendiri', score: { emotionalPattern: 3, attachmentStyle: 1 } },
      { id: 'q5-c', text: 'Mencari dukungan dari orang terdekat', score: { attachmentStyle: 3, emotionalPattern: 2 } },
      { id: 'q5-d', text: 'Mengalihkan fokus ke hal produktif', score: { ambitionLevel: 3, riskTendency: 1 } },
    ],
  },
  {
    id: 'q6',
    text: 'Bagaimana gaya komunikasimu dengan orang lain?',
    category: 'communication',
    options: [
      { id: 'q6-a', text: 'Langsung, jujur, tanpa filter', score: { riskTendency: 3, coreValue: 2 } },
      { id: 'q6-b', text: 'Diplomatis dan mempertimbangkan perasaan', score: { emotionalPattern: 3, attachmentStyle: 2 } },
      { id: 'q6-c', text: 'Dalam dan bermakna', score: { existentialDepth: 3, coreValue: 2 } },
      { id: 'q6-d', text: 'Efisien dan to the point', score: { ambitionLevel: 3, riskTendency: 1 } },
    ],
  },
  {
    id: 'q7',
    text: 'Apa ambisi terbesarmu yang jarang kamu ceritakan?',
    category: 'ambitions',
    options: [
      { id: 'q7-a', text: 'Menciptakan dampak besar pada dunia', score: { ambitionLevel: 3, existentialDepth: 2 } },
      { id: 'q7-b', text: 'Menemukan kedamaian batin yang sejati', score: { coreValue: 3, emotionalPattern: 2 } },
      { id: 'q7-c', text: 'Membangun sesuatu yang abadi', score: { ambitionLevel: 3, coreValue: 2 } },
      { id: 'q7-d', text: 'Memahami diri sendiri sepenuhnya', score: { existentialDepth: 3, emotionalPattern: 2 } },
    ],
  },
  {
    id: 'q8',
    text: 'Ketika melihat orang lain sukses, apa reaksimu?',
    category: 'values',
    options: [
      { id: 'q8-a', text: 'Terinspirasi dan termotivasi', score: { ambitionLevel: 3, coreValue: 2 } },
      { id: 'q8-b', text: 'Bertanya-tanya apa arti sukses bagiku', score: { existentialDepth: 3, coreValue: 2 } },
      { id: 'q8-c', text: 'Merasa senang untuk mereka', score: { emotionalPattern: 3, attachmentStyle: 2 } },
      { id: 'q8-d', text: 'Menganalisis strategi mereka', score: { coreValue: 3, ambitionLevel: 2 } },
    ],
  },
  {
    id: 'q9',
    text: 'Bagaimana kamu menghadapi ketidakpastian?',
    category: 'decision',
    options: [
      { id: 'q9-a', text: 'Melihatnya sebagai petualangan', score: { riskTendency: 3, ambitionLevel: 2 } },
      { id: 'q9-b', text: 'Mencoba mengendalikan apa yang bisa', score: { coreValue: 3, emotionalPattern: 1 } },
      { id: 'q9-c', text: 'Menerima dan mengalir dengannya', score: { existentialDepth: 3, emotionalPattern: 2 } },
      { id: 'q9-d', text: 'Mencari informasi sebanyak mungkin', score: { coreValue: 3, ambitionLevel: 1 } },
    ],
  },
  {
    id: 'q10',
    text: 'Apa yang membuatmu merasa paling hidup?',
    category: 'values',
    options: [
      { id: 'q10-a', text: 'Menciptakan sesuatu yang baru', score: { ambitionLevel: 3, riskTendency: 2 } },
      { id: 'q10-b', text: 'Koneksi mendalam dengan orang lain', score: { attachmentStyle: 3, emotionalPattern: 2 } },
      { id: 'q10-c', text: 'Momen-momen introspeksi', score: { existentialDepth: 3, emotionalPattern: 2 } },
      { id: 'q10-d', text: 'Mengatasi tantangan besar', score: { riskTendency: 3, coreValue: 2 } },
    ],
  },
  {
    id: 'q11',
    text: 'Bagaimana hubunganmu dengan masa lalu?',
    category: 'trauma',
    options: [
      { id: 'q11-a', text: 'Belajar darinya dan move on', score: { coreValue: 3, ambitionLevel: 2 } },
      { id: 'q11-b', text: 'Sering merenungkannya', score: { emotionalPattern: 3, existentialDepth: 2 } },
      { id: 'q11-c', text: 'Menerima sebagai bagian diriku', score: { existentialDepth: 3, coreValue: 2 } },
      { id: 'q11-d', text: 'Berusaha melupakannya', score: { emotionalPattern: 3, riskTendency: 1 } },
    ],
  },
  {
    id: 'q12',
    text: 'Apa yang kamu lakukan ketika merasa sendirian?',
    category: 'emotional',
    options: [
      { id: 'q12-a', text: 'Menulis atau menciptakan sesuatu', score: { ambitionLevel: 3, emotionalPattern: 2 } },
      { id: 'q12-b', text: 'Mendalami pikiran dan perasaan', score: { existentialDepth: 3, emotionalPattern: 3 } },
      { id: 'q12-c', text: 'Mencari aktivitas untuk mengalihkan', score: { riskTendency: 3, coreValue: 1 } },
      { id: 'q12-d', text: 'Mencoba menghubungi seseorang', score: { attachmentStyle: 3, emotionalPattern: 2 } },
    ],
  },
  {
    id: 'q13',
    text: 'Bagaimana pandanganmu tentang cinta?',
    category: 'values',
    options: [
      { id: 'q13-a', text: 'Sesuatu yang dalam dan transformatif', score: { existentialDepth: 3, emotionalPattern: 2 } },
      { id: 'q13-b', text: 'Komitmen dan pilihan setiap hari', score: { coreValue: 3, attachmentStyle: 2 } },
      { id: 'q13-c', text: 'Momen-momen indah yang harus dihargai', score: { emotionalPattern: 3, attachmentStyle: 2 } },
      { id: 'q13-d', text: 'Tantangan yang layak diperjuangkan', score: { ambitionLevel: 3, riskTendency: 2 } },
    ],
  },
  {
    id: 'q14',
    text: 'Apa yang paling kamu takuti tentang dirimu sendiri?',
    category: 'fears',
    options: [
      { id: 'q14-a', text: 'Potensi gelap yang tidak terkendali', score: { emotionalPattern: 3, existentialDepth: 2 } },
      { id: 'q14-b', text: 'Tidak mencapai ekspektasi diri', score: { ambitionLevel: 3, coreValue: 2 } },
      { id: 'q14-c', text: 'Ketergantungan pada orang lain', score: { attachmentStyle: 3, coreValue: 2 } },
      { id: 'q14-d', text: 'Kehilangan passion dan arah', score: { existentialDepth: 3, ambitionLevel: 2 } },
    ],
  },
  {
    id: 'q15',
    text: 'Bagaimana kamu mendefinisikan keberhasilan?',
    category: 'ambitions',
    options: [
      { id: 'q15-a', text: 'Kebebasan untuk menjadi diri sendiri', score: { coreValue: 3, riskTendency: 2 } },
      { id: 'q15-b', text: 'Dampak positif pada orang lain', score: { attachmentStyle: 3, ambitionLevel: 2 } },
      { id: 'q15-c', text: 'Pencapaian tujuan yang ditetapkan', score: { ambitionLevel: 3, coreValue: 2 } },
      { id: 'q15-d', text: 'Kedamaian dan kepuasan batin', score: { existentialDepth: 3, emotionalPattern: 2 } },
    ],
  },
];

const initialScores: PersonalityScore = {
  coreValue: 50,
  emotionalPattern: 50,
  ambitionLevel: 50,
  riskTendency: 50,
  attachmentStyle: 50,
  existentialDepth: 50,
};

export const usePersonalityStore = create<PersonalityState>()(
  persist(
    (set, get) => ({
      currentQuestionIndex: 0,
      answers: {},
      scores: initialScores,
      profile: null,
      isCompleted: false,
      questions,

      setAnswer: (questionId: string, optionId: string, _scores: Record<string, number>) => {
        set((state) => ({
          answers: { ...state.answers, [questionId]: optionId },
        }));
      },

      nextQuestion: () => {
        const { currentQuestionIndex, questions } = get();
        if (currentQuestionIndex < questions.length - 1) {
          set({ currentQuestionIndex: currentQuestionIndex + 1 });
        } else {
          get().calculateScores();
        }
      },

      previousQuestion: () => {
        const { currentQuestionIndex } = get();
        if (currentQuestionIndex > 0) {
          set({ currentQuestionIndex: currentQuestionIndex - 1 });
        }
      },

      calculateScores: () => {
        const { answers, questions } = get();
        const newScores = { ...initialScores };
        
        Object.entries(answers).forEach(([questionId, optionId]) => {
          const question = questions.find(q => q.id === questionId);
          const option = question?.options.find(o => o.id === optionId);
          
          if (option) {
            Object.entries(option.score).forEach(([key, value]) => {
              if (key in newScores) {
                newScores[key as keyof PersonalityScore] += value * 5;
              }
            });
          }
        });

        // Normalize scores to 0-100
        Object.keys(newScores).forEach((key) => {
          newScores[key as keyof PersonalityScore] = Math.min(100, Math.max(0, newScores[key as keyof PersonalityScore]));
        });

        const profile: PersonalityProfile = {
          id: `profile-${Date.now()}`,
          userId: 'current-user',
          scores: newScores,
          dominantTraits: getDominantTraits(newScores),
          analysis: generateAnalysis(newScores),
          createdAt: new Date().toISOString(),
        };

        set({ scores: newScores, profile, isCompleted: true });
      },

      resetScan: () => {
        set({
          currentQuestionIndex: 0,
          answers: {},
          scores: initialScores,
          profile: null,
          isCompleted: false,
        });
      },

      getCurrentQuestion: () => {
        const { questions, currentQuestionIndex } = get();
        return questions[currentQuestionIndex] || null;
      },

      getProgress: () => {
        const { currentQuestionIndex, questions } = get();
        return ((currentQuestionIndex + 1) / questions.length) * 100;
      },
    }),
    {
      name: 'noctura-personality',
    }
  )
);

function getDominantTraits(scores: PersonalityScore): string[] {
  const traits: { key: keyof PersonalityScore; name: string; threshold: number }[] = [
    { key: 'existentialDepth', name: 'Sang Penyelami Makna', threshold: 70 },
    { key: 'ambitionLevel', name: 'Sang Visioner', threshold: 70 },
    { key: 'emotionalPattern', name: 'Sang Empatik', threshold: 70 },
    { key: 'riskTendency', name: 'Sang Petualang', threshold: 70 },
    { key: 'coreValue', name: 'Sang Berprinsip', threshold: 70 },
    { key: 'attachmentStyle', name: 'Sang Penyambung', threshold: 70 },
  ];

  return traits
    .filter(t => scores[t.key] >= t.threshold)
    .map(t => t.name);
}

function generateAnalysis(scores: PersonalityScore): string {
  const parts: string[] = [];
  
  if (scores.existentialDepth > 70) {
    parts.push('Kamu adalah seorang pemikir yang mendalam, selalu mencari makna di balik setiap pengalaman.');
  }
  if (scores.ambitionLevel > 70) {
    parts.push('Visi dan ambisimu mendorongmu untuk terus tumbuh dan mencapai hal-hal besar.');
  }
  if (scores.emotionalPattern > 70) {
    parts.push('Kemampuanmu merasakan dan memahami emosi memberikan kedalaman pada pengalaman hidupmu.');
  }
  if (scores.riskTendency > 70) {
    parts.push('Keberanianmu menghadapi ketidakpastian membuka pintu bagi peluang besar.');
  }
  if (scores.coreValue > 70) {
    parts.push('Prinsip-prinsipmu yang kuat menjadi kompas dalam setiap keputusan.');
  }
  if (scores.attachmentStyle > 70) {
    parts.push('Hubungan dan koneksi dengan orang lain adalah sumber kekuatan bagimu.');
  }

  if (parts.length === 0) {
    parts.push('Kamu memiliki keseimbangan yang langka antara berbagai aspek kepribadian.');
  }

  return parts.join(' ');
}
