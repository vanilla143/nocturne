import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { SimulationScenario, FutureScenario } from '@/types';

interface SimulationState {
  currentSimulation: SimulationScenario | null;
  isGenerating: boolean;
  history: SimulationScenario[];
  generateSimulation: (input: string) => Promise<void>;
  clearCurrent: () => void;
}

const generateScenarios = (input: string): FutureScenario[] => {
  const scenarios: FutureScenario[] = [
    {
      id: `scenario-${Date.now()}-1`,
      title: 'Jalur Optimalisasi',
      probability: 35,
      narrative: `Dalam jalur ini, keputusanmu untuk ${input} membuka pintu-pintu yang tidak pernah kamu bayangkan. Awalnya penuh tantangan, tapi setiap rintangan mengasah kemampuanmu. Dalam 2-3 tahun, kamu menemukan diri berada di posisi yang jauh lebih selaras dengan nilai-nilai inti.`,
      risks: [
        'Ketidakpastian finansial di 6 bulan pertama',
        'Potensi kehilangan beberapa hubungan yang tidak mendukung',
        'Momen keraguan diri yang intens',
      ],
      emotionalConsequences: [
        'Rasa bebas yang mendalam namun menakutkan',
        'Pride yang tumbuh dari keberanian mengambil risiko',
        'Kadang, nostalgia untuk "kenyamanan" masa lalu',
      ],
      growthPotential: [
        'Peningkatan kepercayaan diri yang signifikan',
        'Kemampuan adaptasi yang jauh lebih kuat',
        'Pemahaman lebih dalam tentang prioritas hidup',
      ],
      timeline: '2-5 tahun untuk melihat hasil penuh',
    },
    {
      id: `scenario-${Date.now()}-2`,
      title: 'Jalur Keseimbangan',
      probability: 45,
      narrative: `Jalur ini menunjukkan kompromi yang lebih realistis. Kamu tidak sepenuhnya melepaskan yang lama, tapi perlahan mengintegrasikan ${input} ke dalam hidup. Hasilnya lebih lambat tapi lebih stabil.`,
      risks: [
        'Risiko kelelahan dari menjalankan dua hal sekaligus',
        'Kemungkinan tidak sepenuhnya puas dengan kedua dunia',
        'Waktu yang lebih lama untuk mencapai tujuan',
      ],
      emotionalConsequences: [
        'Rasa aman yang lebih tinggi',
        'Kadang, penyesalan "what if" aku lebih berani',
        'Kepuasan bertahap dari kemajuan konsisten',
      ],
      growthPotential: [
        'Kemampuan manajemen waktu dan prioritas',
        'Pemahaman praktis tentang kompromi hidup',
        'Hubungan yang terjaga sambil mengejar impian',
      ],
      timeline: '3-7 tahun untuk transisi penuh',
    },
    {
      id: `scenario-${Date.now()}-3`,
      title: 'Jalur Refleksi',
      probability: 20,
      narrative: `Dalam skenario ini, ${input} mengajarkanmu sesuatu yang tak terduga - mungkin bahwa yang kamu cari sebenarnya ada di tempat lain. Ini bukan kegagalan, tapi penemuan.`,
      risks: [
        'Perasaan gagal atau "sia-sia" di awal',
        'Tekanan dari ekspektasi orang lain',
        'Potensi krisis identitas sementara',
      ],
      emotionalConsequences: [
        'Kesedihan mendalam tapi transformatif',
        'Penerimaan yang akhirnya membawa kedamaian',
        'Gratitude untuk keberanian mencoba',
      ],
      growthPotential: [
        'Klaritas tentang apa yang sebenarnya penting',
        'Kemampuan melepaskan dan menerima',
        'Kedewasaan emosional yang lebih dalam',
      ],
      timeline: '1-3 tahun untuk pemahaman penuh',
    },
  ];

  return scenarios;
};

export const useSimulationStore = create<SimulationState>()(
  persist(
    (set, get) => ({
      currentSimulation: null,
      isGenerating: false,
      history: [],

      generateSimulation: async (input: string) => {
        set({ isGenerating: true });
        
        // Simulate generation delay
        await new Promise(resolve => setTimeout(resolve, 2500));

        const scenarios = generateScenarios(input);
        
        const simulation: SimulationScenario = {
          id: `sim-${Date.now()}`,
          userId: 'current-user',
          input,
          scenarios,
          createdAt: new Date().toISOString(),
        };

        set({
          currentSimulation: simulation,
          history: [simulation, ...get().history],
          isGenerating: false,
        });
      },

      clearCurrent: () => {
        set({ currentSimulation: null });
      },
    }),
    {
      name: 'noctura-simulation',
    }
  )
);
