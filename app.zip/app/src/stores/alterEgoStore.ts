import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { AlterEgo, PersonalityScore } from '@/types';

interface AlterEgoState {
  alterEgo: AlterEgo | null;
  isGenerating: boolean;
  generateAlterEgo: (name: string, personalityScores: PersonalityScore) => Promise<void>;
  updateAlterEgo: (data: Partial<AlterEgo>) => void;
  updateTone: (tone: AlterEgo['tone']) => void;
  consumeEnergy: (amount: number) => void;
  restoreEnergy: (amount: number) => void;
  unlockTone: (tone: string) => void;
}

const generateAlterEgoDescription = (scores: PersonalityScore, name: string): string => {
  const descriptions: Record<string, string> = {
    highExistential: `Sebuah entitas yang lahir dari kerinduan akan makna. ${name} tidak pernah puas dengan jawaban dangkal dan selalu menggali lebih dalam ke dalam lubuk pikiran.`,
    highAmbition: `Sang visioner yang melihat dunia bukan seperti apa adanya, tapi seperti apa yang bisa dijadikannya. ${name} adalah pengejar impian tanpa ampun.`,
    highEmotional: `Sebuah jiwa yang merasakan segalanya dengan intensitas mendalam. ${name} memahami bahwa kelemahan adalah pintu menuju kekuatan sejati.`,
    balanced: `Entitas yang mencapai keseimbangan langka antara pikiran dan perasaan. ${name} adalah cermin dari potensi tersembunyi yang selalu ada dalam dirimu.`,
    mysterious: `Bayangan yang berbicara dalam bisikan. ${name} adalah misteri yang bahkan dirimu sendiri belum sepenuhnya mengerti.`,
  };

  if (scores.existentialDepth > 80) return descriptions.highExistential;
  if (scores.ambitionLevel > 80) return descriptions.highAmbition;
  if (scores.emotionalPattern > 80) return descriptions.highEmotional;
  if (scores.coreValue > 60 && scores.riskTendency > 60) return descriptions.balanced;
  return descriptions.mysterious;
};

const generateSpeakingStyle = (scores: PersonalityScore): string => {
  const styles: string[] = [];
  
  if (scores.existentialDepth > 70) styles.push('filosofis', 'reflektif');
  if (scores.ambitionLevel > 70) styles.push('tegas', 'visioner');
  if (scores.emotionalPattern > 70) styles.push('empatik', 'dalam');
  if (scores.riskTendency > 70) styles.push('berani', 'langsung');
  if (scores.coreValue > 70) styles.push('bijaksana', 'tenang');
  
  if (styles.length === 0) styles.push('misterius', 'tenang', 'penuh makna');
  
  return styles.join(', ');
};

const generateTitle = (scores: PersonalityScore): string => {
  const titles = [
    { condition: scores.existentialDepth > 80, title: 'Sang Penjawab Keheningan' },
    { condition: scores.ambitionLevel > 80, title: 'Sang Arsitek Mimpi' },
    { condition: scores.emotionalPattern > 80, title: 'Sang Penyelami Jiwa' },
    { condition: scores.riskTendency > 80, title: 'Sang Pemecah Batas' },
    { condition: scores.coreValue > 80, title: 'Sang Penjaga Keseimbangan' },
    { condition: scores.attachmentStyle > 70, title: 'Sang Penyambung Hati' },
  ];

  const matched = titles.find(t => t.condition);
  return matched?.title || 'Sang Bayangan Abadi';
};

export const useAlterEgoStore = create<AlterEgoState>()(
  persist(
    (set, get) => ({
      alterEgo: null,
      isGenerating: false,

      generateAlterEgo: async (name: string, personalityScores: PersonalityScore) => {
        set({ isGenerating: true });
        
        // Simulate generation delay
        await new Promise(resolve => setTimeout(resolve, 2000));

        const alterEgo: AlterEgo = {
          id: `alter-${Date.now()}`,
          userId: 'current-user',
          name,
          title: generateTitle(personalityScores),
          description: generateAlterEgoDescription(personalityScores, name),
          speakingStyle: generateSpeakingStyle(personalityScores),
          tone: 'wise',
          personality: JSON.stringify(personalityScores),
          energy: 100,
          maxEnergy: 100,
          unlockedTones: ['wise'],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

        set({ alterEgo, isGenerating: false });
      },

      updateAlterEgo: (data: Partial<AlterEgo>) => {
        const { alterEgo } = get();
        if (alterEgo) {
          set({
            alterEgo: { ...alterEgo, ...data, updatedAt: new Date().toISOString() },
          });
        }
      },

      updateTone: (tone: AlterEgo['tone']) => {
        const { alterEgo } = get();
        if (alterEgo && alterEgo.unlockedTones.includes(tone)) {
          set({
            alterEgo: { ...alterEgo, tone, updatedAt: new Date().toISOString() },
          });
        }
      },

      consumeEnergy: (amount: number) => {
        const { alterEgo } = get();
        if (alterEgo) {
          const newEnergy = Math.max(0, alterEgo.energy - amount);
          set({
            alterEgo: { ...alterEgo, energy: newEnergy },
          });
        }
      },

      restoreEnergy: (amount: number) => {
        const { alterEgo } = get();
        if (alterEgo) {
          const newEnergy = Math.min(alterEgo.maxEnergy, alterEgo.energy + amount);
          set({
            alterEgo: { ...alterEgo, energy: newEnergy },
          });
        }
      },

      unlockTone: (tone: string) => {
        const { alterEgo } = get();
        if (alterEgo && !alterEgo.unlockedTones.includes(tone)) {
          set({
            alterEgo: {
              ...alterEgo,
              unlockedTones: [...alterEgo.unlockedTones, tone],
              updatedAt: new Date().toISOString(),
            },
          });
        }
      },
    }),
    {
      name: 'noctura-alter-ego',
    }
  )
);
