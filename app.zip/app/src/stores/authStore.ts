import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { User, AuthState } from '@/types';

interface AuthStore extends AuthState {
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  updateUser: (user: Partial<User>) => void;
  addXP: (amount: number) => void;
  setLoading: (loading: boolean) => void;
}

const mockUser: User = {
  id: '1',
  email: 'user@noctura.ai',
  name: 'Seeker',
  avatar: undefined,
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  isPro: false,
  xp: 0,
  level: 1,
  dailyStreak: 0,
};

export const useAuthStore = create<AuthStore>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,
      isLoading: false,
      token: null,

      login: async (_email: string, _password: string) => {
        set({ isLoading: true });
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Mock successful login
        set({
          user: mockUser,
          isAuthenticated: true,
          token: 'mock-jwt-token',
          isLoading: false,
        });
      },

      register: async (name: string, _email: string, _password: string) => {
        set({ isLoading: true });
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        const newUser: User = {
          ...mockUser,
          name,
          email,
        };
        
        set({
          user: newUser,
          isAuthenticated: true,
          token: 'mock-jwt-token',
          isLoading: false,
        });
      },

      logout: () => {
        set({
          user: null,
          isAuthenticated: false,
          token: null,
        });
      },

      updateUser: (userData: Partial<User>) => {
        const { user } = get();
        if (user) {
          set({
            user: { ...user, ...userData, updatedAt: new Date().toISOString() },
          });
        }
      },

      addXP: (amount: number) => {
        const { user } = get();
        if (user) {
          const newXP = user.xp + amount;
          const newLevel = Math.floor(newXP / 1000) + 1;
          set({
            user: {
              ...user,
              xp: newXP,
              level: newLevel > user.level ? newLevel : user.level,
            },
          });
        }
      },

      setLoading: (loading: boolean) => {
        set({ isLoading: loading });
      },
    }),
    {
      name: 'noctura-auth',
      partialize: (state) => ({
        user: state.user,
        isAuthenticated: state.isAuthenticated,
        token: state.token,
      }),
    }
  )
);
