import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Achievement, LevelReward } from '@/types';

interface LevelState {
  level: number;
  xp: number;
  totalXP: number;
  achievements: Achievement[];
  unlockedFeatures: string[];
  unlockedTones: string[];
  addXP: (amount: number, reason?: string) => { leveledUp: boolean; newLevel?: number };
  getXPToNextLevel: () => number;
  getProgress: () => number;
  checkAchievement: (achievementId: string) => void;
  getLevelTitle: () => string;
}

const levelTitles: Record<number, string> = {
  1: 'Pemula',
  2: 'Penjelajah',
  3: 'Pencari',
  4: 'Reflektor',
  5: 'Introspektor',
  6: 'Penyelami Jiwa',
  7: 'Sang Pengamat',
  8: 'Sang Pemikir',
  9: 'Sang Bijaksana',
  10: 'Sang Abadi',
};

const levelRewards: LevelReward[] = [
  { level: 2, reward: 'Mode Brutal Jujur', type: 'tone' },
  { level: 3, reward: 'Export PDF', type: 'feature' },
  { level: 4, reward: 'Mode Filosofis', type: 'tone' },
  { level: 5, reward: 'Daily Reminder', type: 'feature' },
  { level: 6, reward: 'Mode Motivator', type: 'tone' },
  { level: 7, reward: 'Advanced Simulation', type: 'feature' },
  { level: 8, reward: 'Custom Alter Ego Avatar', type: 'feature' },
  { level: 9, reward: 'Priority AI Response', type: 'feature' },
  { level: 10, reward: 'Master Title', type: 'title' },
];

const defaultAchievements: Achievement[] = [
  {
    id: 'first-chat',
    name: 'Pertemuan Pertama',
    description: 'Berbicara dengan alter ego untuk pertama kali',
    icon: 'MessageCircle',
    xpReward: 50,
  },
  {
    id: 'first-simulation',
    name: 'Peramal Masa Depan',
    description: 'Menjalankan simulasi keputusan pertama',
    icon: 'CrystalBall',
    xpReward: 100,
  },
  {
    id: 'first-writing',
    name: 'Penyair Bayangan',
    description: 'Membuat karya tulis pertama',
    icon: 'Pen',
    xpReward: 75,
  },
  {
    id: 'daily-streak-3',
    name: 'Konsisten',
    description: 'Refleksi harian selama 3 hari berturut-turut',
    icon: 'Flame',
    xpReward: 150,
  },
  {
    id: 'daily-streak-7',
    name: 'Sang Disiplin',
    description: 'Refleksi harian selama 7 hari berturut-turut',
    icon: 'Crown',
    xpReward: 300,
  },
  {
    id: 'deep-conversation',
    name: 'Percakapan Mendalam',
    description: 'Chat dengan lebih dari 20 pesan dalam satu sesi',
    icon: 'MessagesSquare',
    xpReward: 100,
  },
  {
    id: 'all-modes',
    name: 'Master Komunikasi',
    description: 'Mencoba semua mode percakapan',
    icon: 'Zap',
    xpReward: 200,
  },
  {
    id: 'level-5',
    name: 'Setengah Perjalanan',
    description: 'Mencapai level 5',
    icon: 'Star',
    xpReward: 500,
  },
  {
    id: 'level-10',
    name: 'Sang Abadi',
    description: 'Mencapai level maksimum',
    icon: 'Sparkles',
    xpReward: 1000,
  },
];

const XP_BASE = 1000;
const XP_MULTIPLIER = 1.5;

export const useLevelStore = create<LevelState>()(
  persist(
    (set, get) => ({
      level: 1,
      xp: 0,
      totalXP: 0,
      achievements: defaultAchievements,
      unlockedFeatures: [],
      unlockedTones: ['wise'],

      addXP: (amount: number, _reason?: string) => {
        const { level, xp, totalXP, achievements } = get();
        const newXP = xp + amount;
        const newTotalXP = totalXP + amount;
        const xpToNext = get().getXPToNextLevel();

        let leveledUp = false;
        let newLevel = level;
        let remainingXP = newXP;
        let unlockedFeatures = [...get().unlockedFeatures];
        let unlockedTones = [...get().unlockedTones];

        // Check for level up
        if (newXP >= xpToNext) {
          leveledUp = true;
          newLevel = level + 1;
          remainingXP = newXP - xpToNext;

          // Check for rewards
          const reward = levelRewards.find(r => r.level === newLevel);
          if (reward) {
            if (reward.type === 'feature') {
              unlockedFeatures.push(reward.reward);
            } else if (reward.type === 'tone') {
              unlockedTones.push(reward.reward.toLowerCase().replace(' mode', ''));
            }
          }

          // Check for level achievements
          if (newLevel === 5) {
            const achievement = achievements.find(a => a.id === 'level-5');
            if (achievement && !achievement.unlockedAt) {
              achievement.unlockedAt = new Date().toISOString();
            }
          }
          if (newLevel === 10) {
            const achievement = achievements.find(a => a.id === 'level-10');
            if (achievement && !achievement.unlockedAt) {
              achievement.unlockedAt = new Date().toISOString();
            }
          }
        }

        set({
          level: newLevel,
          xp: remainingXP,
          totalXP: newTotalXP,
          achievements,
          unlockedFeatures,
          unlockedTones,
        });

        return { leveledUp, newLevel: leveledUp ? newLevel : undefined };
      },

      getXPToNextLevel: () => {
        const { level } = get();
        return Math.floor(XP_BASE * Math.pow(XP_MULTIPLIER, level - 1));
      },

      getProgress: () => {
        const { xp } = get();
        const xpToNext = get().getXPToNextLevel();
        return (xp / xpToNext) * 100;
      },

      checkAchievement: (achievementId: string) => {
        const { achievements } = get();
        const achievement = achievements.find(a => a.id === achievementId);
        
        if (achievement && !achievement.unlockedAt) {
          achievement.unlockedAt = new Date().toISOString();
          set({ achievements: [...achievements] });
          
          // Add XP for achievement
          get().addXP(achievement.xpReward, `Achievement: ${achievement.name}`);
        }
      },

      getLevelTitle: () => {
        const { level } = get();
        return levelTitles[level] || 'Sang Abadi';
      },
    }),
    {
      name: 'noctura-level',
    }
  )
);
