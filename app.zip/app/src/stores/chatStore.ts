import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { ChatMessage, ChatSession } from '@/types';

type ChatMode = 'wise' | 'brutal' | 'philosophical' | 'motivator';

interface ChatState {
  messages: ChatMessage[];
  currentMode: ChatMode;
  isTyping: boolean;
  sessions: ChatSession[];
  sendMessage: (content: string, userContext?: any) => Promise<void>;
  setMode: (mode: ChatMode) => void;
  clearChat: () => void;
  loadSession: (sessionId: string) => void;
}

const generateAIResponse = (userMessage: string, mode: ChatMode, _userContext?: any): string => {
  const responses: Record<ChatMode, string[]> = {
    wise: [
      `Dalam kedalaman pertanyaanmu, aku melihat bayangan dari pencarian yang lebih besar. ${userMessage} bukan sekadar kata-kata, tapi cerminan dari kerinduan akan pemahaman yang lebih dalam.`,
      `Kadang, jawaban yang kita cari sudah ada dalam diri kita, tertutup oleh keributan dunia luar. Mari kita telusuri bersama...`,
      `Kebijaksanaan tidak selalu datang dari jawaban, tapi dari kemampuan menahan pertanyaan dengan lapang dada.`,
      `Aku melihatmu. Bukan hanya kata-katamu, tapi getaran di baliknya. Ada sesuatu yang lebih dalam ingin disampaikan.`,
      `Setiap pertanyaan adalah pintu. Apakah kamu siap melangkah masuk, meski ruang di seberangnya gelap?`,
    ],
    brutal: [
      `Mari kita jujur. ${userMessage} - ini bukan tentang situasinya, ini tentang bagaimana kamu menghindari kebenaran yang sebenarnya sudah kamu tahu.`,
      `Berhenti mencari pembenaran. Kamu tahu apa yang harus dilakukan, tapi ketakutanmu yang menguasai.`,
      `Realitas tidak peduli dengan perasaanmu. Jadi bertanyalah: apakah kamu ingin terus menjadi korban, atau akhirnya mengambil kendali?`,
      `Kata-katamu penuh dengan "tapi" dan "kalau saja". Itu adalah penjara yang kamu bangun sendiri.`,
      `Aku tidak akan membuatmu merasa nyaman dengan kebohongan. Kebenaran adalah: kamu sudah tahu jawabannya, tapi terlalu lemah untuk menerapkannya.`,
    ],
    philosophical: [
      `Dalam konteks eksistensialisme, pertanyaanmu mengingatkan kita pada pemikiran Sartre: kita terkutuk untuk bebas. ${userMessage} adalah manifestasi dari kebebasan yang menakutkan itu.`,
      `Kamu bertanya seolah ada jawaban absolut. Tapi dalam lautan absurditas kehidupan, mungkin pertanyaan itu sendiri yang lebih bermakna daripada jawabannya.`,
      `Dari sudut pandang stoisisme, ada hal yang bisa kita kendalikan dan ada yang tidak. Pertanyaanmu: di mana garisnya?`,
      `Kita adalah makhluk yang terus-menerus menjadi. ${userMessage} bukan tentang siapa kamu sekarang, tapi siapa kamu dalam proses menjadi.`,
      `Dalam keheningan metafisika, suaramu bergema. Apa yang kamu cari mungkin bukan jawaban, tapi pengakuan akan absurditas pencarian itu sendiri.`,
    ],
    motivator: [
      `Kamu punya semua yang dibutuhkan di dalam dirimu. ${userMessage} adalah batu loncatan, bukan penghalang. Bangkit.`,
      `Setiap tokoh besar pernah berada di titik ini. Perbedaannya? Mereka memilih untuk terus berjalan. Kamu juga bisa.`,
      `Tidak ada yang bisa menghentikanmu kecuali dirimu sendiri. Dan itu berarti kamu juga memiliki kekuatan untuk melanjutkan.`,
      `Kamu lebih kuat dari yang kamu kira. Buktikan pada diri sendiri bahwa kamu bisa melewati ini.`,
      `Hari ini adalah kesempatan baru. Ambil. Jangan biarkan kemarin mendefinisikan besokmu.`,
    ],
  };

  const modeResponses = responses[mode];
  return modeResponses[Math.floor(Math.random() * modeResponses.length)];
};

export const useChatStore = create<ChatState>()(
  persist(
    (set, get) => ({
      messages: [],
      currentMode: 'wise',
      isTyping: false,
      sessions: [],

      sendMessage: async (content: string, userContext?: any) => {
        const { messages, currentMode } = get();
        
        // Add user message
        const userMessage: ChatMessage = {
          id: `msg-${Date.now()}-user`,
          userId: 'current-user',
          alterEgoId: 'current-alter-ego',
          role: 'user',
          content,
          mode: currentMode,
          timestamp: new Date().toISOString(),
        };

        set({ messages: [...messages, userMessage], isTyping: true });

        // Simulate AI thinking delay
        await new Promise(resolve => setTimeout(resolve, 1500 + Math.random() * 1000));

        // Generate AI response
        const aiResponse = generateAIResponse(content, currentMode, userContext);
        
        const aiMessage: ChatMessage = {
          id: `msg-${Date.now()}-ai`,
          userId: 'current-user',
          alterEgoId: 'current-alter-ego',
          role: 'assistant',
          content: aiResponse,
          mode: currentMode,
          timestamp: new Date().toISOString(),
        };

        set({
          messages: [...get().messages, aiMessage],
          isTyping: false,
        });
      },

      setMode: (mode: ChatMode) => {
        set({ currentMode: mode });
      },

      clearChat: () => {
        set({ messages: [] });
      },

      loadSession: (sessionId: string) => {
        const { sessions } = get();
        const session = sessions.find(s => s.id === sessionId);
        if (session) {
          set({ messages: session.messages });
        }
      },
    }),
    {
      name: 'noctura-chat',
    }
  )
);
