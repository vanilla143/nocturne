import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Sparkles, User, LogOut } from 'lucide-react';
import { useAuthStore } from '@/stores';

interface NavbarProps {
  onNavigate: (page: string) => void;
  currentPage: string;
}

export function Navbar({ onNavigate, currentPage }: NavbarProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, isAuthenticated, logout } = useAuthStore();

  const navItems = [
    { id: 'home', label: 'Beranda' },
    { id: 'features', label: 'Fitur' },
    { id: 'pricing', label: 'Harga' },
    { id: 'about', label: 'Tentang' },
  ];

  const handleNavigate = (page: string) => {
    onNavigate(page);
    setIsMenuOpen(false);
  };

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
      className="fixed top-0 left-0 right-0 z-50 bg-noctura-dark/80 backdrop-blur-xl border-b border-noctura-border"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <motion.button
            onClick={() => handleNavigate('home')}
            className="flex items-center space-x-2"
            whileHover={{ scale: 1.02 }}
          >
            <Sparkles className="w-6 h-6 text-noctura-purple" />
            <span className="text-xl font-display font-light text-white tracking-tight">
              NOCTURA
            </span>
          </motion.button>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavigate(item.id)}
                className={`nav-link ${currentPage === item.id ? 'text-white' : ''}`}
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Auth Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            {isAuthenticated ? (
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => handleNavigate('dashboard')}
                  className="flex items-center space-x-2 text-noctura-gray-400 hover:text-white transition-colors"
                >
                  <User className="w-5 h-5" />
                  <span className="text-sm">{user?.name}</span>
                </button>
                <button
                  onClick={logout}
                  className="text-noctura-gray-400 hover:text-white transition-colors"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => handleNavigate('login')}
                  className="text-noctura-gray-400 hover:text-white transition-colors text-sm"
                >
                  Masuk
                </button>
                <button
                  onClick={() => handleNavigate('register')}
                  className="btn-primary text-sm"
                >
                  Mulai Perjalanan
                </button>
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden text-white p-2"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-noctura-card border-t border-noctura-border"
          >
            <div className="px-4 py-4 space-y-4">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleNavigate(item.id)}
                  className={`block w-full text-left py-2 ${
                    currentPage === item.id ? 'text-white' : 'text-noctura-gray-400'
                  }`}
                >
                  {item.label}
                </button>
              ))}
              <div className="border-t border-noctura-border pt-4">
                {isAuthenticated ? (
                  <div className="space-y-2">
                    <button
                      onClick={() => handleNavigate('dashboard')}
                      className="block w-full text-left py-2 text-white"
                    >
                      Dashboard
                    </button>
                    <button
                      onClick={logout}
                      className="block w-full text-left py-2 text-noctura-gray-400"
                    >
                      Keluar
                    </button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <button
                      onClick={() => handleNavigate('login')}
                      className="block w-full text-left py-2 text-noctura-gray-400"
                    >
                      Masuk
                    </button>
                    <button
                      onClick={() => handleNavigate('register')}
                      className="btn-primary w-full text-center"
                    >
                      Mulai Perjalanan
                    </button>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
}
