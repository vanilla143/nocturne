import { motion } from 'framer-motion';
import { Sparkles, Github, Twitter, Instagram, Mail } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: string) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="relative py-16 border-t border-noctura-border">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-t from-noctura-darker to-noctura-dark" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="md:col-span-2">
            <motion.button
              onClick={() => onNavigate('home')}
              className="flex items-center space-x-2 mb-4"
              whileHover={{ scale: 1.02 }}
            >
              <Sparkles className="w-6 h-6 text-noctura-purple" />
              <span className="text-xl font-display font-light text-white tracking-tight">
                NOCTURA
              </span>
            </motion.button>
            <p className="text-noctura-gray-400 text-sm max-w-md mb-6">
              Alter Ego Digital — Sistem refleksi diri berbasis psikologi, filosofi, 
              dan simulasi masa depan. Temukan kedalaman yang belum pernah kamu eksplorasi.
            </p>
            <div className="flex space-x-4">
              {[
                { icon: Twitter, href: '#' },
                { icon: Instagram, href: '#' },
                { icon: Github, href: '#' },
                { icon: Mail, href: '#' },
              ].map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  className="w-10 h-10 rounded-lg bg-noctura-card border border-noctura-border flex items-center justify-center text-noctura-gray-400 hover:text-white hover:border-noctura-purple/50 transition-all"
                >
                  <social.icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-white font-medium mb-4">Navigasi</h4>
            <ul className="space-y-2">
              {[
                { label: 'Beranda', page: 'home' },
                { label: 'Fitur', page: 'features' },
                { label: 'Harga', page: 'pricing' },
                { label: 'Tentang', page: 'about' },
              ].map((link) => (
                <li key={link.page}>
                  <button
                    onClick={() => onNavigate(link.page)}
                    className="text-noctura-gray-400 hover:text-white transition-colors text-sm"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="text-white font-medium mb-4">Legal</h4>
            <ul className="space-y-2">
              {[
                'Kebijakan Privasi',
                'Syarat & Ketentuan',
                'Keamanan Data',
              ].map((item) => (
                <li key={item}>
                  <span className="text-noctura-gray-400 text-sm cursor-pointer hover:text-white transition-colors">
                    {item}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="pt-8 border-t border-noctura-border flex flex-col md:flex-row items-center justify-between">
          <p className="text-noctura-gray-500 text-sm">
            {currentYear} NOCTURA. All rights reserved.
          </p>
          <p className="text-noctura-gray-600 text-xs mt-2 md:mt-0">
            Dibuat dengan untuk para pencari makna.
          </p>
        </div>
      </div>
    </footer>
  );
}
