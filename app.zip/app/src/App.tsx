import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Navbar, Footer } from '@/components/layout';
import {
  Hero,
  Features,
  Pricing,
  About,
  Login,
  Register,
  PersonalityScan,
  Dashboard,
  Chat,
  Simulation,
  Writing,
} from '@/sections';
import { useAuthStore, usePersonalityStore } from '@/stores';

type Page = 
  | 'home' 
  | 'features' 
  | 'pricing' 
  | 'about' 
  | 'login' 
  | 'register' 
  | 'onboarding' 
  | 'dashboard' 
  | 'chat' 
  | 'simulation' 
  | 'writing';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const { isAuthenticated } = useAuthStore();
  const { isCompleted } = usePersonalityStore();

  // Redirect to onboarding if authenticated but personality scan not completed
  useEffect(() => {
    if (isAuthenticated && !isCompleted && currentPage === 'dashboard') {
      setCurrentPage('onboarding');
    }
  }, [isAuthenticated, isCompleted, currentPage]);

  const handleNavigate = (page: string) => {
    // Check if user needs to complete onboarding
    if (page === 'dashboard' && isAuthenticated && !isCompleted) {
      setCurrentPage('onboarding');
      return;
    }
    
    // Check if user needs to login for protected pages
    const protectedPages = ['dashboard', 'chat', 'simulation', 'writing'];
    if (protectedPages.includes(page) && !isAuthenticated) {
      setCurrentPage('login');
      return;
    }

    setCurrentPage(page as Page);
    window.scrollTo(0, 0);
  };

  const handleOnboardingComplete = () => {
    setCurrentPage('dashboard');
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return (
          <>
            <Hero onNavigate={handleNavigate} />
            <Features />
            <Pricing onNavigate={handleNavigate} />
            <About />
          </>
        );
      case 'features':
        return <Features />;
      case 'pricing':
        return <Pricing onNavigate={handleNavigate} />;
      case 'about':
        return <About />;
      case 'login':
        return <Login onNavigate={handleNavigate} />;
      case 'register':
        return <Register onNavigate={handleNavigate} />;
      case 'onboarding':
        return <PersonalityScan onComplete={handleOnboardingComplete} />;
      case 'dashboard':
        return <Dashboard onNavigate={handleNavigate} />;
      case 'chat':
        return <Chat />;
      case 'simulation':
        return <Simulation />;
      case 'writing':
        return <Writing />;
      default:
        return (
          <>
            <Hero onNavigate={handleNavigate} />
            <Features />
            <Pricing onNavigate={handleNavigate} />
            <About />
          </>
        );
    }
  };

  const isLandingPage = ['home', 'features', 'pricing', 'about'].includes(currentPage);
  const showFooter = isLandingPage;

  return (
    <div className="min-h-screen bg-noctura-dark">
      <Navbar onNavigate={handleNavigate} currentPage={currentPage} />
      
      <main>
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            {renderPage()}
          </motion.div>
        </AnimatePresence>
      </main>

      {showFooter && <Footer onNavigate={handleNavigate} />}
    </div>
  );
}

export default App;
