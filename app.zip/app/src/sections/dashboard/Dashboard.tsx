import { motion } from 'framer-motion';
import { 
  MessageSquare, 
  Compass, 
  Pen, 
  Zap, 
  TrendingUp, 
  Award,
  Sparkles,
  ChevronRight
} from 'lucide-react';
import { useAuthStore, useAlterEgoStore, useLevelStore } from '@/stores';

interface DashboardProps {
  onNavigate: (page: string) => void;
}

export function Dashboard({ onNavigate }: DashboardProps) {
  const { user } = useAuthStore();
  const { alterEgo } = useAlterEgoStore();
  const { level, xp, getXPToNextLevel, getProgress, getLevelTitle } = useLevelStore();

  const xpToNext = getXPToNextLevel();
  const progress = getProgress();
  const levelTitle = getLevelTitle();

  const quickActions = [
    {
      icon: MessageSquare,
      title: 'Bicara dengan Alter Ego',
      description: 'Mulai percakapan mendalam',
      action: () => onNavigate('chat'),
      color: 'purple',
    },
    {
      icon: Compass,
      title: 'Simulasikan Keputusan',
      description: 'Lihat kemungkinan masa depan',
      action: () => onNavigate('simulation'),
      color: 'blue',
    },
    {
      icon: Pen,
      title: 'Buat Karya Tulis',
      description: 'Ubah emosi menjadi kata-kata',
      action: () => onNavigate('writing'),
      color: 'cyan',
    },
  ];

  const stats = [
    { label: 'Level', value: level, icon: Zap, color: 'text-noctura-purple' },
    { label: 'XP', value: `${xp}/${xpToNext}`, icon: TrendingUp, color: 'text-noctura-blue' },
    { label: 'Gelar', value: levelTitle, icon: Award, color: 'text-noctura-cyan' },
  ];

  return (
    <div className="min-h-screen pt-24 pb-12 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-noctura-dark via-noctura-purple/5 to-noctura-dark" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Welcome */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <h1 className="text-3xl md:text-4xl font-display font-light text-white mb-2">
            Selamat datang, <span className="gradient-text">{user?.name}</span>
          </h1>
          <p className="text-noctura-gray-400">
            {alterEgo ? `${alterEgo.name} menunggumu untuk berbicara.` : 'Lengkapi profilmu untuk memulai.'}
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Quick Actions */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="grid md:grid-cols-3 gap-4"
            >
              {quickActions.map((action, index) => (
                <motion.button
                  key={action.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.1 + index * 0.1 }}
                  onClick={action.action}
                  className="glass-card-hover p-6 text-left group"
                >
                  <div className={`w-12 h-12 rounded-xl bg-noctura-${action.color}/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                    <action.icon className={`w-6 h-6 text-noctura-${action.color}`} />
                  </div>
                  <h3 className="text-white font-medium mb-1">{action.title}</h3>
                  <p className="text-noctura-gray-400 text-sm">{action.description}</p>
                  <ChevronRight className="w-5 h-5 text-noctura-gray-500 mt-4 group-hover:text-noctura-purple group-hover:translate-x-1 transition-all" />
                </motion.button>
              ))}
            </motion.div>

            {/* Alter Ego Card */}
            {alterEgo && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="glass-card p-6"
              >
                <div className="flex items-start justify-between mb-6">
                  <div>
                    <span className="badge-purple mb-2 inline-block">Alter Ego</span>
                    <h2 className="text-2xl font-display font-medium text-white">{alterEgo.name}</h2>
                    <p className="text-noctura-purple text-sm">{alterEgo.title}</p>
                  </div>
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-noctura-purple to-noctura-blue flex items-center justify-center">
                    <Sparkles className="w-8 h-8 text-white" />
                  </div>
                </div>

                <p className="text-noctura-gray-300 mb-6 leading-relaxed">
                  {alterEgo.description}
                </p>

                <div className="grid md:grid-cols-2 gap-4 mb-6">
                  <div className="glass-card p-4">
                    <p className="text-noctura-gray-400 text-xs mb-1">Gaya Bicara</p>
                    <p className="text-white text-sm">{alterEgo.speakingStyle}</p>
                  </div>
                  <div className="glass-card p-4">
                    <p className="text-noctura-gray-400 text-xs mb-1">Mode Aktif</p>
                    <p className="text-white text-sm capitalize">{alterEgo.tone}</p>
                  </div>
                </div>

                {/* Energy Bar */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-noctura-gray-400 text-sm">Energi Alter Ego</span>
                    <span className="text-white text-sm">{alterEgo.energy}%</span>
                  </div>
                  <div className="energy-indicator">
                    <motion.div
                      className="energy-fill"
                      initial={{ width: 0 }}
                      animate={{ width: `${alterEgo.energy}%` }}
                      transition={{ duration: 0.5 }}
                    />
                  </div>
                </div>
              </motion.div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Stats */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="glass-card p-6"
            >
              <h3 className="text-white font-medium mb-4">Statistik</h3>
              <div className="space-y-4">
                {stats.map((stat) => (
                  <div key={stat.label} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <stat.icon className={`w-5 h-5 ${stat.color}`} />
                      <span className="text-noctura-gray-400 text-sm">{stat.label}</span>
                    </div>
                    <span className="text-white font-medium">{stat.value}</span>
                  </div>
                ))}
              </div>

              {/* Level Progress */}
              <div className="mt-6 pt-6 border-t border-noctura-border">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-noctura-gray-400 text-sm">Progress ke Level {level + 1}</span>
                  <span className="text-noctura-purple text-sm">{Math.round(progress)}%</span>
                </div>
                <div className="progress-bar">
                  <motion.div
                    className="progress-fill"
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    transition={{ duration: 0.5 }}
                  />
                </div>
              </div>
            </motion.div>

            {/* Daily Quote */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="glass-card p-6"
            >
              <h3 className="text-white font-medium mb-4">Kutipan Hari Ini</h3>
              <blockquote className="text-noctura-gray-300 text-sm italic leading-relaxed mb-3">
                "Kegelapan bukanlah keberadaan, melainkan absennya cahaya. Begitu pula dengan kekosongan — 
                ia adalah ruang yang menunggu untuk diisi."
              </blockquote>
              <cite className="text-noctura-gray-500 text-xs">— NOCTURA</cite>
            </motion.div>

            {/* Tips */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="glass-card p-6"
            >
              <h3 className="text-white font-medium mb-4">Tips Hari Ini</h3>
              <p className="text-noctura-gray-300 text-sm leading-relaxed">
                Coba mode "Brutal Jujur" saat berbicara dengan alter egomu. 
                Kadang kita butuh kejujuran yang menyakitkan untuk tumbuh.
              </p>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
