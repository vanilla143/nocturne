// Landing
export { Hero } from './landing/Hero';
export { Features } from './landing/Features';
export { Pricing } from './landing/Pricing';
export { About } from './landing/About';

// Auth
export { Login } from './auth/Login';
export { Register } from './auth/Register';

// Onboarding
export { PersonalityScan } from './onboarding/PersonalityScan';

// Dashboard
export { Dashboard } from './dashboard/Dashboard';

// Chat
export { Chat } from './chat/Chat';

// Simulation
export { Simulation } from './simulation/Simulation';

// Writing
export { Writing } from './writing/Writing';
