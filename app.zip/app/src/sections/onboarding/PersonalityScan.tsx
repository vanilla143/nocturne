import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronRight, ChevronLeft, Sparkles, Brain, Loader2 } from 'lucide-react';
import { usePersonalityStore, useAlterEgoStore } from '@/stores';

interface PersonalityScanProps {
  onComplete: () => void;
}

export function PersonalityScan({ onComplete }: PersonalityScanProps) {
  const [alterEgoName, setAlterEgoName] = useState('');
  const [showNameInput, setShowNameInput] = useState(false);
  
  const {
    currentQuestionIndex,
    answers,
    questions,
    isCompleted,
    profile,
    setAnswer,
    nextQuestion,
    previousQuestion,
    getProgress,
    getCurrentQuestion,
  } = usePersonalityStore();

  const { generateAlterEgo, isGenerating } = useAlterEgoStore();

  const currentQuestion = getCurrentQuestion();
  const progress = getProgress();

  const handleSelectOption = (optionId: string, scores: Record<string, number>) => {
    if (currentQuestion) {
      setAnswer(currentQuestion.id, optionId, scores);
    }
  };

  const handleNext = () => {
    if (currentQuestion && answers[currentQuestion.id]) {
      nextQuestion();
    }
  };

  const handlePrevious = () => {
    previousQuestion();
  };

  const handleComplete = async () => {
    if (alterEgoName.trim() && profile) {
      await generateAlterEgo(alterEgoName.trim(), profile.scores);
      onComplete();
    }
  };

  // Show completion screen
  if (isCompleted && profile) {
    return (
      <div className="min-h-screen flex items-center justify-center relative overflow-hidden pt-16">
        <div className="absolute inset-0 bg-gradient-to-b from-noctura-dark via-noctura-purple/10 to-noctura-dark" />
        
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="relative z-10 w-full max-w-2xl px-4"
        >
          <div className="glass-card p-8 text-center">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="w-20 h-20 rounded-full bg-noctura-purple/20 flex items-center justify-center mx-auto mb-6"
            >
              <Brain className="w-10 h-10 text-noctura-purple" />
            </motion.div>

            <h2 className="text-3xl font-display font-medium text-white mb-4">
              Profil Psikologis Terbentuk
            </h2>

            <p className="text-noctura-gray-400 mb-8">
              {profile.analysis}
            </p>

            {/* Scores */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
              {[
                { label: 'Nilai Inti', value: profile.scores.coreValue, color: 'purple' },
                { label: 'Pola Emosional', value: profile.scores.emotionalPattern, color: 'blue' },
                { label: 'Tingkat Ambisi', value: profile.scores.ambitionLevel, color: 'cyan' },
                { label: 'Kecenderungan Risiko', value: profile.scores.riskTendency, color: 'purple' },
                { label: 'Gaya Attachment', value: profile.scores.attachmentStyle, color: 'blue' },
                { label: 'Kedalaman Eksistensial', value: profile.scores.existentialDepth, color: 'cyan' },
              ].map((item) => (
                <div key={item.label} className="glass-card p-4">
                  <p className="text-noctura-gray-400 text-xs mb-1">{item.label}</p>
                  <div className="flex items-center space-x-2">
                    <div className="flex-1 progress-bar">
                      <div
                        className={`progress-fill bg-noctura-${item.color}`}
                        style={{ width: `${item.value}%` }}
                      />
                    </div>
                    <span className="text-white text-sm font-medium">{item.value}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Dominant Traits */}
            {profile.dominantTraits.length > 0 && (
              <div className="mb-8">
                <p className="text-noctura-gray-400 text-sm mb-3">Sifat Dominan</p>
                <div className="flex flex-wrap justify-center gap-2">
                  {profile.dominantTraits.map((trait) => (
                    <span key={trait} className="badge-purple">
                      {trait}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Name Input */}
            {!showNameInput ? (
              <motion.button
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                onClick={() => setShowNameInput(true)}
                className="btn-primary"
              >
                Lanjutkan ke Alter Ego
              </motion.button>
            ) : (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-4"
              >
                <p className="text-white text-lg mb-4">
                  Beri nama pada alter ego digitalmu
                </p>
                <input
                  type="text"
                  value={alterEgoName}
                  onChange={(e) => setAlterEgoName(e.target.value)}
                  placeholder="Contoh: Umbra, Vesper, Noctis..."
                  className="input-noctura text-center text-lg"
                  maxLength={20}
                />
                <button
                  onClick={handleComplete}
                  disabled={!alterEgoName.trim() || isGenerating}
                  className="btn-primary w-full flex items-center justify-center space-x-2 disabled:opacity-50"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      <span>Menciptakan...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5" />
                      <span>Ciptakan Alter Ego</span>
                    </>
                  )}
                </button>
              </motion.div>
            )}
          </div>
        </motion.div>
      </div>
    );
  }

  // Show question
  if (!currentQuestion) return null;

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden pt-16">
      <div className="absolute inset-0 bg-gradient-to-b from-noctura-dark via-noctura-purple/5 to-noctura-dark" />
      
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="relative z-10 w-full max-w-2xl px-4"
      >
        {/* Progress */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-noctura-gray-400 text-sm">
              Pertanyaan {currentQuestionIndex + 1} dari {questions.length}
            </span>
            <span className="text-noctura-purple text-sm">{Math.round(progress)}%</span>
          </div>
          <div className="progress-bar">
            <motion.div
              className="progress-fill"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>
        </div>

        {/* Question Card */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentQuestion.id}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
            className="glass-card p-8"
          >
            <span className="badge-purple mb-4 inline-block">
              {currentQuestion.category === 'values' && 'Nilai'}
              {currentQuestion.category === 'fears' && 'Ketakutan'}
              {currentQuestion.category === 'ambitions' && 'Ambisi'}
              {currentQuestion.category === 'conflict' && 'Konflik'}
              {currentQuestion.category === 'decision' && 'Keputusan'}
              {currentQuestion.category === 'trauma' && 'Luka'}
              {currentQuestion.category === 'communication' && 'Komunikasi'}
            </span>

            <h3 className="text-xl md:text-2xl text-white font-light mb-8">
              {currentQuestion.text}
            </h3>

            <div className="space-y-3">
              {currentQuestion.options.map((option, index) => (
                <motion.button
                  key={option.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                  onClick={() => handleSelectOption(option.id, option.score)}
                  className={`w-full p-4 rounded-xl border text-left transition-all duration-300 ${
                    answers[currentQuestion.id] === option.id
                      ? 'border-noctura-purple bg-noctura-purple/20'
                      : 'border-noctura-border bg-noctura-card hover:border-noctura-purple/30'
                  }`}
                >
                  <span className="text-white">{option.text}</span>
                </motion.button>
              ))}
            </div>

            {/* Navigation */}
            <div className="flex items-center justify-between mt-8">
              <button
                onClick={handlePrevious}
                disabled={currentQuestionIndex === 0}
                className="flex items-center space-x-2 text-noctura-gray-400 hover:text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <ChevronLeft className="w-5 h-5" />
                <span>Sebelumnya</span>
              </button>

              <button
                onClick={handleNext}
                disabled={!answers[currentQuestion.id]}
                className="flex items-center space-x-2 btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <span>{currentQuestionIndex === questions.length - 1 ? 'Selesai' : 'Selanjutnya'}</span>
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </motion.div>
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
