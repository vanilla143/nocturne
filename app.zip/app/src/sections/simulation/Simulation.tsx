import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Compass, Sparkles, AlertTriangle, Heart, TrendingUp, Loader2, X, RefreshCw } from 'lucide-react';
import { useSimulationStore, useLevelStore } from '@/stores';

export function Simulation() {
  const [input, setInput] = useState('');
  const [selectedScenario, setSelectedScenario] = useState<string | null>(null);
  
  const { currentSimulation, isGenerating, generateSimulation, clearCurrent } = useSimulationStore();
  const { addXP } = useLevelStore();

  const handleGenerate = async () => {
    if (!input.trim()) return;
    
    await generateSimulation(input.trim());
    addXP(50, 'Future simulation');
  };

  const handleReset = () => {
    clearCurrent();
    setInput('');
    setSelectedScenario(null);
  };

  return (
    <div className="min-h-screen pt-24 pb-12 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-noctura-dark via-noctura-blue/5 to-noctura-dark" />

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <span className="badge-blue mb-4 inline-block">
            <Compass className="w-3 h-3 inline mr-1" />
            Future Simulation Engine
          </span>
          <h1 className="section-title mb-4">
            Simulasikan <span className="gradient-text">Masa Depan</span>
          </h1>
          <p className="section-subtitle max-w-2xl mx-auto">
            Masukkan keputusan atau pilihan hidup yang sedang kamu pertimbangkan. 
            Sistem akan menghasilkan 3 kemungkinan skenario dengan analisis mendalam.
          </p>
        </motion.div>

        {/* Input Section */}
        {!currentSimulation && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="glass-card p-8 mb-8"
          >
            <label className="block text-white text-lg mb-4">
              Apa keputusan yang ingin kamu simulasikan?
            </label>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Contoh: Saya ingin keluar dari pekerjaan dan fokus bermusik..."
              className="input-noctura w-full h-32 resize-none mb-4"
            />
            <button
              onClick={handleGenerate}
              disabled={!input.trim() || isGenerating}
              className="btn-primary w-full flex items-center justify-center space-x-2 disabled:opacity-50"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>Mensimulasikan...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  <span>Generate Simulasi</span>
                </>
              )}
            </button>
          </motion.div>
        )}

        {/* Results */}
        {currentSimulation && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-6"
          >
            {/* Input Display */}
            <div className="glass-card p-6 flex items-start justify-between">
              <div>
                <p className="text-noctura-gray-400 text-sm mb-2">Skenario untuk:</p>
                <p className="text-white text-lg">{currentSimulation.input}</p>
              </div>
              <button
                onClick={handleReset}
                className="p-2 text-noctura-gray-400 hover:text-white transition-colors"
              >
                <RefreshCw className="w-5 h-5" />
              </button>
            </div>

            {/* Scenarios Grid */}
            <div className="grid md:grid-cols-3 gap-6">
              {currentSimulation.scenarios.map((scenario, index) => (
                <motion.div
                  key={scenario.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  onClick={() => setSelectedScenario(scenario.id)}
                  className={`glass-card-hover p-6 cursor-pointer ${
                    selectedScenario === scenario.id ? 'border-noctura-purple' : ''
                  }`}
                >
                  <div className="flex items-center justify-between mb-4">
                    <span className={`badge ${
                      index === 0 ? 'badge-purple' : index === 1 ? 'badge-blue' : 'badge-cyan'
                    }`}>
                      {scenario.probability}% kemungkinan
                    </span>
                  </div>
                  <h3 className="text-xl font-medium text-white mb-3">{scenario.title}</h3>
                  <p className="text-noctura-gray-400 text-sm line-clamp-3">{scenario.narrative}</p>
                  <p className="text-noctura-purple text-sm mt-4">Klik untuk detail</p>
                </motion.div>
              ))}
            </div>

            {/* Detailed View */}
            <AnimatePresence>
              {selectedScenario && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="glass-card p-8"
                >
                  {currentSimulation.scenarios
                    .filter(s => s.id === selectedScenario)
                    .map(scenario => (
                      <div key={scenario.id}>
                        <div className="flex items-center justify-between mb-6">
                          <h3 className="text-2xl font-medium text-white">{scenario.title}</h3>
                          <button
                            onClick={() => setSelectedScenario(null)}
                            className="p-2 text-noctura-gray-400 hover:text-white transition-colors"
                          >
                            <X className="w-5 h-5" />
                          </button>
                        </div>

                        <p className="text-noctura-gray-300 leading-relaxed mb-8">
                          {scenario.narrative}
                        </p>

                        <div className="grid md:grid-cols-3 gap-6">
                          {/* Risks */}
                          <div className="glass-card p-4">
                            <div className="flex items-center space-x-2 mb-4">
                              <AlertTriangle className="w-5 h-5 text-red-400" />
                              <h4 className="text-white font-medium">Risiko</h4>
                            </div>
                            <ul className="space-y-2">
                              {scenario.risks.map((risk, i) => (
                                <li key={i} className="text-noctura-gray-400 text-sm flex items-start space-x-2">
                                  <span className="text-red-400 mt-1">•</span>
                                  <span>{risk}</span>
                                </li>
                              ))}
                            </ul>
                          </div>

                          {/* Emotional Consequences */}
                          <div className="glass-card p-4">
                            <div className="flex items-center space-x-2 mb-4">
                              <Heart className="w-5 h-5 text-pink-400" />
                              <h4 className="text-white font-medium">Dampak Emosional</h4>
                            </div>
                            <ul className="space-y-2">
                              {scenario.emotionalConsequences.map((consequence, i) => (
                                <li key={i} className="text-noctura-gray-400 text-sm flex items-start space-x-2">
                                  <span className="text-pink-400 mt-1">•</span>
                                  <span>{consequence}</span>
                                </li>
                              ))}
                            </ul>
                          </div>

                          {/* Growth Potential */}
                          <div className="glass-card p-4">
                            <div className="flex items-center space-x-2 mb-4">
                              <TrendingUp className="w-5 h-5 text-green-400" />
                              <h4 className="text-white font-medium">Potensi Pertumbuhan</h4>
                            </div>
                            <ul className="space-y-2">
                              {scenario.growthPotential.map((growth, i) => (
                                <li key={i} className="text-noctura-gray-400 text-sm flex items-start space-x-2">
                                  <span className="text-green-400 mt-1">•</span>
                                  <span>{growth}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>

                        <div className="mt-6 pt-6 border-t border-noctura-border">
                          <p className="text-noctura-gray-400 text-sm">
                            <span className="text-white">Timeline:</span> {scenario.timeline}
                          </p>
                        </div>
                      </div>
                    ))}
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}
      </div>
    </div>
  );
}
