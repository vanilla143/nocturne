import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Send, 
  Sparkles, 
  Trash2, 
  Brain,
  Flame,
  Lightbulb,
  Heart
} from 'lucide-react';
import { useChatStore, useAlterEgoStore, useLevelStore } from '@/stores';

type ChatMode = 'wise' | 'brutal' | 'philosophical' | 'motivator';

const modes: { id: ChatMode; label: string; icon: typeof Brain; description: string }[] = [
  { id: 'wise', label: 'Bijak', icon: Brain, description: 'Tenang, mendalam, penuh pengertian' },
  { id: 'brutal', label: 'Brutal Jujur', icon: Flame, description: 'Langsung, tanpa filter, menantang' },
  { id: 'philosophical', label: 'Filosofis', icon: Lightbulb, description: 'Eksistensial, reflektif, abstrak' },
  { id: 'motivator', label: 'Motivator', icon: Heart, description: 'Enerjik, mendukung, action-oriented' },
];

export function Chat() {
  const [input, setInput] = useState('');
  const [showModeMenu, setShowModeMenu] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const { messages, currentMode, isTyping, sendMessage, setMode, clearChat } = useChatStore();
  const { alterEgo, consumeEnergy } = useAlterEgoStore();
  const { addXP } = useLevelStore();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    const message = input.trim();
    setInput('');
    
    // Consume energy
    consumeEnergy(5);
    
    await sendMessage(message);
    
    // Add XP
    addXP(10, 'Chat message');
  };

  const handleModeChange = (mode: ChatMode) => {
    setMode(mode);
    setShowModeMenu(false);
    addXP(5, 'Mode change');
  };

  const currentModeInfo = modes.find(m => m.id === currentMode);

  return (
    <div className="min-h-screen pt-20 pb-4 relative flex flex-col">
      <div className="absolute inset-0 bg-gradient-to-b from-noctura-dark via-noctura-purple/5 to-noctura-dark" />

      <div className="relative z-10 flex-1 flex flex-col max-w-4xl mx-auto w-full px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card p-4 mb-4 flex items-center justify-between"
        >
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-noctura-purple to-noctura-blue flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-white font-medium">{alterEgo?.name || 'Alter Ego'}</h2>
              <p className="text-noctura-gray-400 text-sm">{alterEgo?.title || 'Digital Companion'}</p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {/* Mode Selector */}
            <div className="relative">
              <button
                onClick={() => setShowModeMenu(!showModeMenu)}
                className="flex items-center space-x-2 px-4 py-2 bg-noctura-card border border-noctura-border rounded-lg hover:border-noctura-purple/50 transition-colors"
              >
                {currentModeInfo && (
                  <>
                    <currentModeInfo.icon className="w-4 h-4 text-noctura-purple" />
                    <span className="text-white text-sm hidden sm:inline">{currentModeInfo.label}</span>
                  </>
                )}
              </button>

              <AnimatePresence>
                {showModeMenu && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute right-0 top-full mt-2 w-64 glass-card border border-noctura-border rounded-xl overflow-hidden z-50"
                  >
                    {modes.map((mode) => (
                      <button
                        key={mode.id}
                        onClick={() => handleModeChange(mode.id)}
                        className={`w-full p-4 text-left flex items-start space-x-3 hover:bg-noctura-purple/10 transition-colors ${
                          currentMode === mode.id ? 'bg-noctura-purple/20' : ''
                        }`}
                      >
                        <mode.icon className={`w-5 h-5 mt-0.5 ${
                          currentMode === mode.id ? 'text-noctura-purple' : 'text-noctura-gray-400'
                        }`} />
                        <div>
                          <p className={`text-sm font-medium ${
                            currentMode === mode.id ? 'text-white' : 'text-noctura-gray-300'
                          }`}>
                            {mode.label}
                          </p>
                          <p className="text-noctura-gray-500 text-xs">{mode.description}</p>
                        </div>
                      </button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Menu */}
            <button
              onClick={clearChat}
              className="p-2 text-noctura-gray-400 hover:text-white transition-colors"
              title="Hapus percakapan"
            >
              <Trash2 className="w-5 h-5" />
            </button>
          </div>
        </motion.div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto space-y-4 mb-4 px-2">
          {messages.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-12"
            >
              <Sparkles className="w-12 h-12 text-noctura-purple mx-auto mb-4" />
              <h3 className="text-white text-lg mb-2">Mulai Percakapan</h3>
              <p className="text-noctura-gray-400 text-sm max-w-md mx-auto">
                Katakan sesuatu pada alter ego digitalmu. Ia sudah mengenalmu dari hasil personality scan.
              </p>
            </motion.div>
          )}

          {messages.map((message, index) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[80%] ${
                message.role === 'user' ? 'chat-bubble-user' : 'chat-bubble-ai'
              }`}>
                <p className="text-white whitespace-pre-wrap">{message.content}</p>
                <p className="text-noctura-gray-500 text-xs mt-2">
                  {new Date(message.timestamp).toLocaleTimeString('id-ID', { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                  })}
                </p>
              </div>
            </motion.div>
          ))}

          {isTyping && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex justify-start"
            >
              <div className="chat-bubble-ai">
                <div className="flex space-x-2">
                  <motion.div
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ duration: 0.6, repeat: Infinity }}
                    className="w-2 h-2 bg-noctura-purple rounded-full"
                  />
                  <motion.div
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ duration: 0.6, repeat: Infinity, delay: 0.2 }}
                    className="w-2 h-2 bg-noctura-purple rounded-full"
                  />
                  <motion.div
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ duration: 0.6, repeat: Infinity, delay: 0.4 }}
                    className="w-2 h-2 bg-noctura-purple rounded-full"
                  />
                </div>
              </div>
            </motion.div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card p-4"
        >
          <div className="flex items-center space-x-4">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Katakan sesuatu..."
              className="flex-1 input-noctura"
              disabled={isTyping}
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || isTyping}
              className="p-3 bg-noctura-purple rounded-lg text-white hover:bg-noctura-purple-glow transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
