import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Pen, Sparkles, Loader2, Download, RefreshCw, X, FileText } from 'lucide-react';
import { useWritingStore, useLevelStore } from '@/stores';
import jsPDF from 'jspdf';

type WritingType = 'poem' | 'reflection' | 'letter' | 'monologue';
type WritingStyle = 'poetic' | 'minimalist' | 'dark' | 'realistic' | 'existential';

const writingTypes: { id: WritingType; label: string; description: string }[] = [
  { id: 'poem', label: 'Puisi', description: 'Ungkapan dalam bait dan baris' },
  { id: 'reflection', label: 'Refleksi', description: 'Pemikiran mendalam 1 halaman' },
  { id: 'letter', label: 'Surat', description: 'Surat untuk diri sendiri' },
  { id: 'monologue', label: 'Monolog', description: 'Narasi sinematik' },
];

const writingStyles: { id: WritingStyle; label: string; description: string }[] = [
  { id: 'poetic', label: 'Puitis', description: 'Indah, metaforis, penuh imaji' },
  { id: 'minimalist', label: 'Minimalis', description: 'Sederhana, padat, to the point' },
  { id: 'dark', label: 'Gelap', description: 'Mencekam, introspektif, dalam' },
  { id: 'realistic', label: 'Realistis', description: 'Jujur, apa adanya, tanpa filter' },
  { id: 'existential', label: 'Eksistensial', description: 'Filosofis, abstrak, mendalam' },
];

export function Writing() {
  const [input, setInput] = useState('');
  const [selectedType, setSelectedType] = useState<WritingType>('poem');
  const [selectedStyle, setSelectedStyle] = useState<WritingStyle>('poetic');
  const [showExport, setShowExport] = useState(false);
  
  const { currentPiece, isGenerating, generateWriting, clearCurrent } = useWritingStore();
  const { addXP } = useLevelStore();

  const handleGenerate = async () => {
    if (!input.trim()) return;
    
    await generateWriting(input.trim(), selectedType, selectedStyle);
    addXP(30, 'Writing generated');
  };

  const handleExportPDF = () => {
    if (!currentPiece) return;

    const doc = new jsPDF();
    
    // Title
    doc.setFontSize(20);
    doc.setTextColor(139, 92, 246); // Purple color
    doc.text(currentPiece.title, 20, 30);
    
    // Subtitle
    doc.setFontSize(12);
    doc.setTextColor(100, 100, 100);
    doc.text(`NOCTURA - ${new Date(currentPiece.createdAt).toLocaleDateString('id-ID')}`, 20, 40);
    
    // Content
    doc.setFontSize(11);
    doc.setTextColor(50, 50, 50);
    const splitContent = doc.splitTextToSize(currentPiece.content, 170);
    doc.text(splitContent, 20, 55);
    
    // Footer
    doc.setFontSize(10);
    doc.setTextColor(150, 150, 150);
    doc.text('Dibuat dengan NOCTURA - Alter Ego Digital', 20, 280);
    
    doc.save(`noctura-${currentPiece.title.toLowerCase().replace(/\s+/g, '-')}.pdf`);
    
    addXP(10, 'PDF exported');
    setShowExport(false);
  };

  const handleReset = () => {
    clearCurrent();
    setInput('');
  };

  return (
    <div className="min-h-screen pt-24 pb-12 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-noctura-dark via-noctura-cyan/5 to-noctura-dark" />

      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <span className="badge-cyan mb-4 inline-block">
            <Pen className="w-3 h-3 inline mr-1" />
            Auto Writing Generator
          </span>
          <h1 className="section-title mb-4">
            Ubah Emosi menjadi <span className="gradient-text">Kata-kata</span>
          </h1>
          <p className="section-subtitle max-w-2xl mx-auto">
            Ketik satu kalimat emosi, dan biarkan sistem mengubahnya menjadi 
            puisi, refleksi, surat, atau monolog yang mendalam.
          </p>
        </motion.div>

        {!currentPiece ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="space-y-6"
          >
            {/* Input */}
            <div className="glass-card p-6">
              <label className="block text-white text-lg mb-4">
                Apa yang kamu rasakan saat ini?
              </label>
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Contoh: Aku merasa kosong..."
                className="input-noctura w-full text-lg"
              />
            </div>

            {/* Type Selection */}
            <div className="glass-card p-6">
              <label className="block text-white mb-4">Pilih Format</label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {writingTypes.map((type) => (
                  <button
                    key={type.id}
                    onClick={() => setSelectedType(type.id)}
                    className={`p-4 rounded-xl border text-left transition-all ${
                      selectedType === type.id
                        ? 'border-noctura-purple bg-noctura-purple/20'
                        : 'border-noctura-border bg-noctura-card hover:border-noctura-purple/30'
                    }`}
                  >
                    <p className={`font-medium ${selectedType === type.id ? 'text-white' : 'text-noctura-gray-300'}`}>
                      {type.label}
                    </p>
                    <p className="text-noctura-gray-500 text-xs mt-1">{type.description}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Style Selection */}
            <div className="glass-card p-6">
              <label className="block text-white mb-4">Pilih Gaya</label>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                {writingStyles.map((style) => (
                  <button
                    key={style.id}
                    onClick={() => setSelectedStyle(style.id)}
                    className={`p-4 rounded-xl border text-left transition-all ${
                      selectedStyle === style.id
                        ? 'border-noctura-cyan bg-noctura-cyan/20'
                        : 'border-noctura-border bg-noctura-card hover:border-noctura-cyan/30'
                    }`}
                  >
                    <p className={`font-medium ${selectedStyle === style.id ? 'text-white' : 'text-noctura-gray-300'}`}>
                      {style.label}
                    </p>
                    <p className="text-noctura-gray-500 text-xs mt-1">{style.description}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Generate Button */}
            <button
              onClick={handleGenerate}
              disabled={!input.trim() || isGenerating}
              className="btn-primary w-full flex items-center justify-center space-x-2 disabled:opacity-50"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>Menciptakan...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  <span>Generate Karya</span>
                </>
              )}
            </button>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-6"
          >
            {/* Result Card */}
            <div className="glass-card p-8">
              <div className="flex items-start justify-between mb-6">
                <div>
                  <span className="badge-cyan mb-2 inline-block">
                    {writingTypes.find(t => t.id === currentPiece.type)?.label} • {' '}
                    {writingStyles.find(s => s.id === currentPiece.style)?.label}
                  </span>
                  <h2 className="text-2xl font-display font-medium text-white">
                    {currentPiece.title}
                  </h2>
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => setShowExport(true)}
                    className="p-2 text-noctura-gray-400 hover:text-white transition-colors"
                    title="Export ke PDF"
                  >
                    <Download className="w-5 h-5" />
                  </button>
                  <button
                    onClick={handleReset}
                    className="p-2 text-noctura-gray-400 hover:text-white transition-colors"
                    title="Buat baru"
                  >
                    <RefreshCw className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Original Input */}
              <div className="mb-6 p-4 bg-noctura-card rounded-lg border-l-4 border-noctura-purple">
                <p className="text-noctura-gray-400 text-sm mb-1">Berdasarkan:</p>
                <p className="text-white italic">"{currentPiece.input}"</p>
              </div>

              {/* Content */}
              <div className="prose prose-invert max-w-none">
                <pre className="whitespace-pre-wrap font-sans text-noctura-gray-200 leading-relaxed">
                  {currentPiece.content}
                </pre>
              </div>

              {/* Timestamp */}
              <p className="text-noctura-gray-500 text-sm mt-6 pt-6 border-t border-noctura-border">
                Dibuat pada {new Date(currentPiece.createdAt).toLocaleString('id-ID')}
              </p>
            </div>

            {/* Export Modal */}
            <AnimatePresence>
              {showExport && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
                  onClick={() => setShowExport(false)}
                >
                  <motion.div
                    initial={{ scale: 0.95 }}
                    animate={{ scale: 1 }}
                    exit={{ scale: 0.95 }}
                    className="glass-card p-6 max-w-sm w-full"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-white text-lg font-medium">Export Karya</h3>
                      <button
                        onClick={() => setShowExport(false)}
                        className="text-noctura-gray-400 hover:text-white"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                    <button
                      onClick={handleExportPDF}
                      className="btn-primary w-full flex items-center justify-center space-x-2"
                    >
                      <FileText className="w-5 h-5" />
                      <span>Download PDF</span>
                    </button>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}
      </div>
    </div>
  );
}
