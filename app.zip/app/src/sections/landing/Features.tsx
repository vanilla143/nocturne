import { motion } from 'framer-motion';
import { Brain, MessageSquare, Compass, Pen, Zap, Shield } from 'lucide-react';

const features = [
  {
    icon: Brain,
    title: 'Deep Personality Scan',
    description: '15 pertanyaan mendalam yang menganalisis nilai hidup, ketakutan, ambisi, dan pola emosionalmu untuk membuat profil psikologis yang akurat.',
    color: 'purple',
  },
  {
    icon: MessageSquare,
    title: 'AI Conversation Mode',
    description: 'Bicara dengan alter ego digitalmu dalam 4 mode berbeda: Bijak, Brutal Jujur, Filosofis, dan Motivator. Setiap respons personal dan reflektif.',
    color: 'blue',
  },
  {
    icon: Compass,
    title: 'Future Simulation Engine',
    description: 'Simulasikan keputusan hidup penting dan lihat 3 kemungkinan masa depan dengan narasi sinematik, risiko, dan potensi pertumbuhan.',
    color: 'cyan',
  },
  {
    icon: Pen,
    title: 'Auto Writing Generator',
    description: 'Ubah satu kalimat emosi menjadi puisi, refleksi, surat untuk diri sendiri, atau monolog sinematik dengan berbagai gaya penulisan.',
    color: 'purple',
  },
  {
    icon: Zap,
    title: 'Level & Achievement System',
    description: 'Dapatkan XP dari refleksi harian, naik level, dan unlock fitur-fitur baru. Gamifikasi ringan untuk memotivasi perjalanan introspeksi.',
    color: 'blue',
  },
  {
    icon: Shield,
    title: 'Privasi & Keamanan',
    description: 'Semua data dan refleksi pribadimu dienkripsi dan aman. Kami tidak pernah menjual atau membagikan data pengguna.',
    color: 'cyan',
  },
];

export function Features() {
  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-noctura-dark via-noctura-purple/5 to-noctura-dark" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="badge-purple mb-4 inline-block">Fitur Utama</span>
          <h2 className="section-title mb-4">
            Alat untuk <span className="gradient-text">Eksplorasi Diri</span>
          </h2>
          <p className="section-subtitle max-w-2xl mx-auto">
            Setiap fitur dirancang untuk membantumu memahami diri sendiri dengan lebih dalam,
            bukan sekadar memberikan jawaban instan.
          </p>
        </motion.div>

        {/* Feature Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="glass-card-hover p-6 group"
            >
              <div className={`w-12 h-12 rounded-xl bg-noctura-${feature.color}/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                <feature.icon className={`w-6 h-6 text-noctura-${feature.color}`} />
              </div>
              <h3 className="card-title mb-2">{feature.title}</h3>
              <p className="card-text">{feature.description}</p>
            </motion.div>
          ))}
        </div>

        {/* How It Works */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-24"
        >
          <div className="text-center mb-12">
            <h3 className="section-title mb-4">Bagaimana Cara Kerjanya?</h3>
            <p className="section-subtitle">Tiga langkah sederhana untuk memulai perjalanan introspeksi</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: '01',
                title: 'Personality Scan',
                description: 'Jawab 15 pertanyaan mendalam untuk membuat profil psikologismu.',
              },
              {
                step: '02',
                title: 'Ciptakan Alter Ego',
                description: 'Sistem akan menghasilkan alter ego digital berdasarkan profilmu.',
              },
              {
                step: '03',
                title: 'Mulai Percakapan',
                description: 'Bicara, simulasikan, dan refleksikan dengan alter ego digitalmu.',
              },
            ].map((item, index) => (
              <motion.div
                key={item.step}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.4 + index * 0.1 }}
                className="text-center"
              >
                <div className="text-6xl font-display font-light text-noctura-purple/30 mb-4">
                  {item.step}
                </div>
                <h4 className="text-xl font-medium text-white mb-2">{item.title}</h4>
                <p className="text-noctura-gray-400 text-sm">{item.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
