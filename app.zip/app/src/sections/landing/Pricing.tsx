import { motion } from 'framer-motion';
import { Check, Sparkles, Zap } from 'lucide-react';

interface PricingProps {
  onNavigate: (page: string) => void;
}

const plans = [
  {
    name: 'Free',
    price: '0',
    description: 'Coba NOCTURA dan rasakan pengalaman dasar',
    icon: Sparkles,
    features: [
      'Personality Scan lengkap',
      '1 Alter Ego',
      '20 pesan chat per hari',
      '2 simulasi per minggu',
      '3 karya tulis per minggu',
      'Level system dasar',
    ],
    cta: 'Mulai Gratis',
    highlighted: false,
  },
  {
    name: 'Pro',
    price: '99.000',
    period: '/bulan',
    description: 'Akses penuh untuk perjalanan introspeksi mendalam',
    icon: Zap,
    features: [
      'Semua fitur Free',
      'Unlimited chat',
      'Unlimited simulasi',
      'Unlimited karya tulis',
      'Export PDF',
      'Daily reflection reminder',
      'Custom alter ego avatar',
      'Priority AI response',
      'Advanced analytics',
    ],
    cta: 'Upgrade ke Pro',
    highlighted: true,
  },
];

export function Pricing({ onNavigate }: PricingProps) {
  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-noctura-dark via-noctura-blue/5 to-noctura-dark" />

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="badge-blue mb-4 inline-block">Harga</span>
          <h2 className="section-title mb-4">
            Pilih <span className="gradient-text">Perjalananmu</span>
          </h2>
          <p className="section-subtitle max-w-2xl mx-auto">
            Mulai gratis dan upgrade kapan saja untuk pengalaman yang lebih dalam.
            Tidak ada komitmen, batalkan kapan saja.
          </p>
        </motion.div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-2 gap-8">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={`relative rounded-2xl p-8 ${
                plan.highlighted
                  ? 'bg-gradient-to-b from-noctura-purple/20 to-noctura-blue/10 border-2 border-noctura-purple/50'
                  : 'glass-card border border-noctura-border'
              }`}
            >
              {plan.highlighted && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <span className="badge-purple text-sm">Paling Populer</span>
                </div>
              )}

              <div className="flex items-center space-x-3 mb-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                  plan.highlighted ? 'bg-noctura-purple/30' : 'bg-noctura-card'
                }`}>
                  <plan.icon className={`w-5 h-5 ${
                    plan.highlighted ? 'text-noctura-purple' : 'text-noctura-gray-400'
                  }`} />
                </div>
                <h3 className="text-2xl font-display font-medium text-white">{plan.name}</h3>
              </div>

              <div className="mb-4">
                <span className="text-4xl font-display font-light text-white">Rp{plan.price}</span>
                {plan.period && <span className="text-noctura-gray-400">{plan.period}</span>}
              </div>

              <p className="text-noctura-gray-400 text-sm mb-6">{plan.description}</p>

              <ul className="space-y-3 mb-8">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start space-x-3">
                    <Check className={`w-5 h-5 mt-0.5 flex-shrink-0 ${
                      plan.highlighted ? 'text-noctura-purple' : 'text-noctura-gray-500'
                    }`} />
                    <span className="text-noctura-gray-300 text-sm">{feature}</span>
                  </li>
                ))}
              </ul>

              <button
                onClick={() => onNavigate(plan.name === 'Free' ? 'register' : 'register')}
                className={`w-full py-3 rounded-lg font-medium transition-all duration-300 ${
                  plan.highlighted
                    ? 'btn-primary'
                    : 'btn-secondary'
                }`}
              >
                {plan.cta}
              </button>
            </motion.div>
          ))}
        </div>

        {/* Guarantee */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="text-center mt-12"
        >
          <p className="text-noctura-gray-500 text-sm">
            7 hari garansi uang kembali. Tidak puas? Dapatkan refund penuh, tanpa pertanyaan.
          </p>
        </motion.div>
      </div>
    </section>
  );
}
