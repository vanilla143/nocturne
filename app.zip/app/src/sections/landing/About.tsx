import { motion } from 'framer-motion';
import { Quote, Heart, Eye, Brain } from 'lucide-react';

export function About() {
  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-noctura-dark via-noctura-cyan/5 to-noctura-dark" />

      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="badge-cyan mb-4 inline-block">Tentang</span>
          <h2 className="section-title mb-4">
            Mengapa <span className="gradient-text">NOCTURA</span>?
          </h2>
        </motion.div>

        {/* Quote */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="glass-card p-8 mb-16 text-center"
        >
          <Quote className="w-8 h-8 text-noctura-purple mx-auto mb-4" />
          <blockquote className="text-xl md:text-2xl text-white font-light italic mb-4">
            "Siapa yang melihat ke luar, bermimpi. Siapa yang melihat ke dalam, terjaga."
          </blockquote>
          <cite className="text-noctura-gray-400">— Carl Jung</cite>
        </motion.div>

        {/* Philosophy */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="space-y-8"
        >
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: Eye,
                title: 'Introspeksi',
                description: 'Kami percaya bahwa jawaban terbaik untuk pertanyaan hidup ada di dalam diri sendiri. NOCTURA adalah cermin digital yang membantumu melihat lebih jelas.',
              },
              {
                icon: Brain,
                title: 'Psikologi',
                description: 'Setiap fitur dirancang berdasarkan prinsip psikologi modern. Bukan gimmick, tapi alat yang benar-benar membantu pertumbuhan pribadi.',
              },
              {
                icon: Heart,
                title: 'Autentisitas',
                description: 'Kami tidak percaya pada "positif thinking" yang dipaksakan. NOCTURA menerima segala bentuk emosi, termasuk yang gelap dan kompleks.',
              },
            ].map((item, index) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
                className="text-center"
              >
                <div className="w-12 h-12 rounded-xl bg-noctura-purple/20 flex items-center justify-center mx-auto mb-4">
                  <item.icon className="w-6 h-6 text-noctura-purple" />
                </div>
                <h3 className="text-lg font-medium text-white mb-2">{item.title}</h3>
                <p className="text-noctura-gray-400 text-sm leading-relaxed">{item.description}</p>
              </motion.div>
            ))}
          </div>

          {/* Story */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="glass-card p-8 mt-12"
          >
            <h3 className="text-xl font-medium text-white mb-4">Cerita di Balik NOCTURA</h3>
            <div className="space-y-4 text-noctura-gray-300 leading-relaxed">
              <p>
                NOCTURA lahir dari kerinduan akan ruang yang aman untuk introspeksi. Di era yang penuh dengan 
                distraksi dan ekspektasi luar, kami ingin menciptakan tempat di mana kamu bisa berhenti sejenak, 
                menatap ke dalam, dan bertanya: "Siapa aku sebenarnya?"
              </p>
              <p>
                Nama "NOCTURA" berasal dari kata "nocturnal" — makhluk yang aktif di malam hari. 
                Karena seringkali, momen-momen refleksi paling dalam terjadi ketika dunia di luar telah tidur, 
                dan kita sendirian dengan pikiran kita sendiri.
              </p>
              <p>
                Alter ego digital bukanlah pengganti diri kita, tapi cermin yang memantulkan aspek-aspek 
                tersembunyi — potensi, ketakutan, dan kebijaksanaan yang mungkin belum kita sadari.
              </p>
            </div>
          </motion.div>

          {/* Target Audience */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="mt-12 text-center"
          >
            <h3 className="text-xl font-medium text-white mb-4">Untuk Siapa NOCTURA?</h3>
            <div className="flex flex-wrap justify-center gap-3">
              {[
                'Usia 18-35 tahun',
                'Kreatif & reflektif',
                'Suka overthinking',
                'Peduli self-development',
                'Suka desain minimalis',
                'Cari makna hidup',
              ].map((tag) => (
                <span
                  key={tag}
                  className="px-4 py-2 bg-noctura-card border border-noctura-border rounded-full text-noctura-gray-300 text-sm"
                >
                  {tag}
                </span>
              ))}
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
